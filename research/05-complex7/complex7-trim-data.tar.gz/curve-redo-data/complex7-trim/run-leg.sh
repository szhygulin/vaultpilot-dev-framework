#!/usr/bin/env bash
# Wrapper to launch a single leg with all env vars correctly set.
# Usage: bash run-leg.sh <leg>
set -euo pipefail
LEG="${1:-}"
WT="/home/szhygulin/dev/vaultpilot/vaultpilot-dev-framework/.claude/worktrees/trim-complex7"
cd "$WT"
export VP_DEV_CLAUDE_BIN="$WT/node_modules/@anthropic-ai/claude-agent-sdk-linux-x64/claude"
export SCRATCH_CLONES_DIR=/tmp/tailored-scratch
export OUT_DIR="$WT/research/curve-redo-data/complex7-trim"
export REPLICATES=1
export VP_DEV_MAX_COST_USD=5
exec bash research/curve-redo-data/complex7-trim/dispatch-trim.sh "$LEG" --parallel 3
