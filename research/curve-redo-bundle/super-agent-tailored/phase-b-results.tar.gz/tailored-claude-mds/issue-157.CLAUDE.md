# Tailored CLAUDE.md for issue #157 (szhygulin/vaultpilot-dev-framework)

Built by `research/curve-redo-bundle/super-agent-tailored/build-tailored-agents.cjs`.
Source: `research/curve-redo-bundle/super-agent/agent-super.CLAUDE.md` (122 sections).
Selector: claude-opus-4-7[1m]; kept 7/122 sections.

<!-- run:run-2026-05-04T14-37-10-004Z issue:#33 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Consolidate commit-phase steps to avoid turn exhaustion before final git commit

**After tests pass, commit within 2 turns: combine `git add` and `git commit -m "..."` in one Bash call — no interim diff reviews, no temp-file message drafts, no redundant `git status` or `git fetch` calls.**
**Why:** Agents burn turns in the cleanup phase (reviewing diffs of already-reviewed files, writing commit messages to `/tmp/`, re-running builds that just passed) and hit the 50-turn ceiling before issuing `git commit`, leaving complete, tested work uncommitted.
**How to apply:** The moment `npm test` (or equivalent) is green and you know which files changed, issue `git add -A && git commit -m "<message>"` immediately — one Bash call. Don't split staging, committing, and verification across separate turns.
**Tells:** Last tool calls show ≥3 consecutive git diff / git status / git fetch / Write-to-/tmp/ calls with no `git commit` issued — the agent is in stall-loop review mode after implementation is already done.
**Guard rule:** Never write a commit message to a temp file; write it inline. Never re-run a build that just passed clean. If you catch yourself doing either, skip straight to the commit call.

<!-- run:run-2026-05-05T20-22-10-610Z issue:#157 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Emit canonical monitoring-command breadcrumbs at CLI launch-time transitions

**Any CLI command that starts a long-running process and writes a run-ID / state file should immediately print the canonical status command before returning control.** Absent that breadcrumb, agents and operators default to shell forensics (`pgrep`, `ls -lt logs/`, manual grep) even when a first-class status path exists.

**Why:** The forensics pattern compounds: each downstream agent independently rediscovers the run state via indirect means, wasting turns and producing fragile, path-specific discovery logic. The fix is trivially cheap — one `process.stdout.write` block at the exact moment the run becomes active.

**How to apply:** Identify the line where the run ID / active-run marker is committed to disk (e.g., `writeCurrentRunId`). Immediately after that line, print `Run launched`, the run ID, and the exact invocations for spot-check (`vp-dev status`) and live-tail (`vp-dev status --watch`). Mirror a shorter hint wherever the 'confirm token' or plan summary is printed.

**Tells:** Issue titles or descriptions containing 'shell-grovel', 'pgrep', 'ls -lt logs', 'forensics', or 'how is the run going' — especially when a dedicated status subcommand already exists but isn't being used.

<!-- run:run-2026-05-05T16-51-01-872Z issue:#136 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## New stdout output at run completion must precede the terminal sentinel, never follow it

**Any human-readable block emitted at run end — reports, summaries, cost rollups — must be written before the `run.completed` sentinel, never after it.**
**Why:** External watchers anchor on the sentinel being the absolute last stdout line; inserting new output after it silently breaks `tail -F | awk '/^run.completed /{exit}'`-style consumers with no error signal.
**How to apply:** In `cmdRun`, `runResume`, and any future run-completion path, emit new content in the `finally` block strictly before the sentinel write. Preserve pre-feature behavior with a `--no-report`-style escape-hatch flag so callers that don't want the extra block stay unaffected.
**Tells:** Any `process.stdout.write` addition inside a run-completion `finally` block; features that add lines "after" the run finishes; issues asking for richer terminal output at completion.
<!-- promote-candidate:watcher-contract -->
The `run.completed` sentinel line functions as a machine-readable termination anchor for external log-tail watchers. When `vp-dev run` or `vp-dev run --resume` adds new human-readable output blocks at completion, those blocks are inserted before the sentinel — never after — so that `tail -F | awk '/^run.completed /{exit}'` consumers remain correct without modification. A `--no-report` flag suppresses the new block, restoring the pre-feature stdout contract for callers that depend on minimal output.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T20-46-43-739Z issue:#161 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Remediation hints must pre-check the target command's own eligibility before surfacing

**When a warning or diagnostic surfaces a 'run `vp-dev X <id>`' line, the formatting code must evaluate X's own hard preconditions — not only the caller's threshold — before choosing that branch of text.**

**Why:** The overload detector (CLAUDE.md >= 30 KB OR tags >= 50 OR issuesHandled >= 20) and the splitter clusterer (attributable sections >= `SPLIT_MIN_SECTIONS`) are independent; the pre-dispatch preview told operators to run `vp-dev agents split` for agents the splitter would refuse with 'Too few attributable sections (<4) to cluster meaningfully.' 4 of 5 flagged agents hit a dead-end UX.

**How to apply:** Any time a `formatXPreview` or status-formatter adds a remediation line, import and evaluate the target command's eligibility constant (e.g., `SPLIT_MIN_SECTIONS`) before selecting that branch. Fall through to an alternate path (e.g., compaction) when eligibility fails. Consolidate the floor into a single named export so both the command and the formatter share one source of truth.

**Tells:** Two subsystems with separate boolean thresholds; a hint that names a follow-up CLI command; that command has its own hard precondition that is NOT a subset of the caller's threshold.

<!-- promote-candidate:splitter-eligibility -->
The overload detector and the splitter clusterer carry independent eligibility criteria. An agent can exceed the overload threshold (CLAUDE.md >= 30 KB OR tags >= 50 OR issuesHandled >= 20) without meeting the splitter's hard floor (attributable sections >= SPLIT_MIN_SECTIONS, currently 4). Pre-dispatch preview code that surfaces a split hint without checking attributableSections will send operators to a command that hard-refuses. The fix is to extend the overload verdict with attributableSections and branch the remediation text at the formatter layer, using a single exported constant shared between split.ts and setup.ts.
<!-- /promote-candidate -->

<!-- run:run-2026-05-03T05-54-13-869Z issue:#62 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Commit-push-envelope must be consecutive turns; pre-commit verification burns kill the envelope

**After `git push` succeeds, emit the decision envelope in the very next turn — no intervening reads, greps, or build re-checks.**

**Why:** Agents that front-load exhaustive verification (build → typecheck → test → grep wiring checks) before the final commit+push consume most of the 50-turn budget. The push lands on turn 49 and there is no turn left to emit the envelope. The SDK sees an unfinished run and records a crash, discarding all the work even though the branch was pushed.

**How to apply:** Treat the final sequence as atomic and inviolable: `git add/commit` → `git push` → emit envelope. If optional validation (typecheck, test, grep cross-checks) hasn't been done yet, skip it rather than defer the envelope. The pushed branch is recoverable; a missing envelope is not.

**Tells:** Five or more of build/typecheck/test/grep calls appearing in the last 15 turns before the first commit attempt signals the budget is almost gone — stop verifying and push immediately.

**Corollary:** If the issue fix requires iterative build-fix cycles, do them in the first half of the turn budget. Reserve the second half for commit + push + envelope only.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#86 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Create the PR immediately after push — post-push verification burns turns needed for the deliverable

**After `git push` succeeds, call `gh pr create` as the very next action — before any `git log`, `git show --stat`, or `gh pr list` checks.**

**Why:** Post-push verification steps (confirming commit hashes, listing PRs, inspecting file stats) consume turns without advancing toward the actual deliverable. When a turn ceiling is close, these confirmation calls prevent PR creation from completing — leaving a fully-committed, fully-pushed branch with no open PR, which recovery passes can't fix in 4 turns if they also burn turns on re-verification.

**How to apply:** Write the PR body to a temp file early in the session (right after tests pass). After push, immediately call `gh pr create --body-file`. Reserve `git log` / `gh pr list` / `git show` only as diagnostics *if* the create step itself fails or returns an error.

**Tells:** Seeing `git log --oneline`, `git show --stat`, and `gh pr list` all appearing *after* `git push` but *before* `gh pr create` is the signature of turn-exhaustion-before-delivery risk.

<!-- run:run-2026-05-01T18-04-35-881Z issue:#614 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Audit the existing implementation before accepting a bug report's premise about missing behavior

**Rule:** When a report claims 'endpoint X never probes Y,' trace the full execution path — SDK restore hooks, background timers, per-request guards — before accepting the gap as real or writing new code.
**Why:** Reporters see a surface symptom (e.g., a stale status field, an opaque error string) without knowing the underlying pipeline. Accepting the premise unchecked risks duplicating existing probes, masking the real root cause, and growing technical debt.
**How to apply:** Grep the relevant subsystem for the claimed missing behavior first. If the behavior already exists at multiple layers, the reporter's proposed fix is likely mis-targeted; redirect attention to the actual anomaly (e.g., error serialization, rendering, asymmetric code paths).
**Tells:** Report proposes adding a probe or check to a thin status/health function; related issues already exist for the same symptom class; the reported error output (e.g., `[object Object]`) doesn't match what a missing-probe failure would produce.
**Secondary signal:** An opaque stringified error (`[object Object]`) in a codebase with typed error classes is its own bug — suggest retargeting to error rendering before adding new checks.
