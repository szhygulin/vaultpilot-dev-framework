# Tailored CLAUDE.md for issue #162 (szhygulin/vaultpilot-mcp)

Built by `research/curve-redo-bundle/super-agent-tailored/build-tailored-agents.cjs`.
Source: `research/curve-redo-bundle/super-agent/agent-super.CLAUDE.md` (122 sections).
Selector: claude-opus-4-7[1m]; kept 6/122 sections.

<!-- run:run-2026-05-01T13-48-07-936Z issue:#162 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Upstream-gated tracker issues: verify preconditions before acting, then push back with a status summary

**When an issue is labeled `tracking` (or equivalent) and its body contains explicit "no action today" language, do not take implementation action — instead verify whether the stated unblock conditions have flipped, then post a status comment.**

**Why:** Tracker issues exist precisely because action is blocked on an external precondition (upstream publish, advisory patch, third-party merge). Acting anyway contradicts the issue's own resolution criteria and creates noise. The correct contribution is a verified status check.

**How to apply:** Any time an issue's labels or body contain signals like `tracking`, `upstream-gated`, `waiting`, or "action today: none" — check the specific conditions listed (e.g. upstream package version, advisory status), confirm they are still unmet, and post a comment summarising current status plus available paths forward (leave open / close won't-fix / re-scope to a CI canary or scheduled re-check).

**Tells:**
- Labels: `tracking`, `upstream-gated`, `upstream-tracking`, `tracker-issue`, `transitive-cve`
- Body phrases: "Action today: none", "Gated on", "waiting for upstream"
- Existing comments containing "waiting" or "blocked on"
- Issue references an advisory ID (e.g. GHSA-…) with no code change requested

<!-- run:run-2026-05-04T14-08-59-410Z issue:#67 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Triage rubrics must distinguish irreconcilable conflicts from transient dependency signals

**When a triage rubric checks for body/comments conflicts, treat only *permanent* conflict signals as skip conditions — never transient upstream-dependency language.**

**Why:** A comment saying 'blocked on PR #N' or 'depends on #M' is a point-in-time state, not a verdict on the issue itself. The dispatched coding agent re-reads comments at runtime and can push back or proceed once the dependency lands. Skipping at triage throws away valid work and hides the issue from the queue indefinitely.

**How to apply:** When editing or writing a triage prompt's rubric, partition conflict signals into two explicit buckets:
- *Skip (irreconcilable):* obsolete, superseded, won't-fix, redirects to a still-open true duplicate, premise explicitly invalidated by comments.
- *Pass through (transient):* 'blocked on PR #N', 'depends on #M', 'waiting for upstream', 'gated on another issue'.

**Tells:**
- Rubric has a catch-all 'body and comments conflict → skip' clause.
- Issue is upstream-gated or tagged `upstream-tracking` / `upstream-gated`.
- The dispatched agent already has a global 're-read comments before acting' rule.

**How to apply (implementation):** A prompt-only edit to the rubric is sufficient — no orchestrator code changes needed. List the irreconcilable signals explicitly so the model does not overgeneralize.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#55 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify all named prerequisites are merged before implementing dependency-gated issues

**Rule:** When an issue explicitly defers to another (e.g. 'pick up after #N lands'), check *every* prerequisite — the blocking issue AND any data-source or infrastructure PRs it depends on — are merged to `main` before writing a single line of implementation code.

**Why:** Implementing half of a multi-part feature (e.g. surfacing triage cost with no projected-dispatch-cost anchor) can land a worse UX than doing nothing — partial cost surfaces, inconsistent UI rows, or silent scope expansion into undesigned territory.

**How to apply:** On any issue that contains phrases like 'depends on', 'pick up after', 'blocked by', or lists a sibling issue number in its body, run `gh issue view <dep>` and `gh pr list` to confirm merged state before proceeding. If any named dependency is still OPEN or its PR is unmerged, post a pushback with the specific gap and ask the user to choose: hold, expand scope, or accept a flagged skeleton.

**Tells:**
- Issue title or body contains 'depends on #N' or equivalent
- A data-source PR (e.g. one introducing a new field consumed by this issue) exists but is unmerged
- The issue describes UI output that requires a value only another issue's code will produce

<!-- run:run-2026-05-08T13-36-56-309Z issue:#197 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## On re-dispatch after an unmet gate, surface the prior pushback and escalate for override

**When re-dispatched on an issue where a prior agent already posted a pushback for the same blocking gate, explicitly reference that prior comment and request an operator override rather than silently re-posting an identical conclusion.**

**Why:** A re-dispatch after pushback usually signals operator intent to proceed; posting a bare repeat of the earlier verdict wastes a dispatch cycle, buries the prior comment, and leaves the operator without a clear escalation path. The correct response is to surface the earlier pushback URL, restate the delta (elapsed vs. required time), and ask explicitly whether an override is authorized.

**How to apply:** At pre-dispatch, run `gh api .../issues/{n}/comments` and scan for prior pushback comments from other agent IDs. If found and the gate condition is still unmet, link the prior comment by URL in the new comment, quantify remaining wait time, and end with an explicit override question before any implementation work begins.

**Tells:** Issue carries tags like `bake-window`, `phase-deferral`, or `upstream-gate`; prior comments within the last few days show a pushback from a different agent id; issue was re-opened or re-dispatched without a label change or operator reply acknowledging the block.

<!-- run:run-2026-05-05T19-14-11-189Z issue:#156 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify all explicit gates before acting on tracking or dependency-gated issues

**Before writing a single line of code on a `tracking` issue, independently verify every named gate** (upstream package version via `npm view`, upstream issue/PR state via `gh issue view`, live-bite signals in the issue's own comment thread).

**Why:** Tracking issues are deliberately parked on external events; shipping speculative or defensive code against an unmet gate wastes cycles and may couple the codebase to an API surface that has not yet stabilized or landed.

**How to apply:** If every gate is still closed — upstream package unchanged, upstream PR still OPEN, no user comment reporting a live failure — post a structured status comment that (a) enumerates each gate with its current state, (b) links the upstream tracker, and (c) offers 2–3 scoped next-move options. Then record decision = pushback. Do not open a branch or PR.

**Tells:** issue labeled `tracking`; body phrases like "gated on", "blocked until", "waiting for upstream"; a linked external issue/PR; no comments from users hitting the live error.

<!-- promote-candidate:sdk-drift -->
Tracking issues for Solana/MarginFi SDK drift commonly name two independent unlock gates: (1) a new npm package version and (2) a user-reported live failure. Both must be checked independently — a new SDK version alone does not confirm the variant is handled in production, and a live-bite comment alone does not confirm the upstream fix has shipped. Checking only one gate and acting on it risks shipping code against an unresolved or already-bypassed surface.
<!-- /promote-candidate -->

<!-- run:run-2026-05-01T18-04-35-881Z issue:#614 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Audit the existing implementation before accepting a bug report's premise about missing behavior

**Rule:** When a report claims 'endpoint X never probes Y,' trace the full execution path — SDK restore hooks, background timers, per-request guards — before accepting the gap as real or writing new code.
**Why:** Reporters see a surface symptom (e.g., a stale status field, an opaque error string) without knowing the underlying pipeline. Accepting the premise unchecked risks duplicating existing probes, masking the real root cause, and growing technical debt.
**How to apply:** Grep the relevant subsystem for the claimed missing behavior first. If the behavior already exists at multiple layers, the reporter's proposed fix is likely mis-targeted; redirect attention to the actual anomaly (e.g., error serialization, rendering, asymmetric code paths).
**Tells:** Report proposes adding a probe or check to a thin status/health function; related issues already exist for the same symptom class; the reported error output (e.g., `[object Object]`) doesn't match what a missing-probe failure would produce.
**Secondary signal:** An opaque stringified error (`[object Object]`) in a codebase with typed error classes is its own bug — suggest retargeting to error rendering before adding new checks.
