# Tailored CLAUDE.md for issue #172 (szhygulin/vaultpilot-dev-framework)

Built by `research/curve-redo-bundle/super-agent-tailored/build-tailored-agents.cjs`.
Source: `research/curve-redo-bundle/super-agent/agent-super.CLAUDE.md` (122 sections).
Selector: claude-opus-4-7[1m]; kept 17/122 sections.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#56 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify dependency PR merge status before implementing features that build on them

**Rule:** Before starting implementation of any issue that cites upstream PRs as prerequisites, confirm each cited PR is actually merged to `main` (not just closed or open) by checking `gh pr view <N> --json state,mergedAt`.

**Why:** Issue bodies can misstate PR status (e.g., 'PR #50 merged' when it was closed-unmerged). Building on absent foundations wastes effort and produces dead code — or worse, silently diverges from actual `main` behavior.

**How to apply:** Any time an issue references prior PRs, task numbers, or preceding agents' work as a prerequisite for the new feature, run the status check before touching any source file. If a dependency is missing, push back with a concrete list of blocked items and offer alternatives (block, reframe, or stub).

**Tells:**
- Issue body contains phrases like 'after PR #N is merged', 'depends on', 'builds on', or references specific outcome types / data structures not visible in `HEAD`.
- Grep for the key symbols (functions, types, file paths) introduced by the cited PR returns no results on `main`.

<!-- run:run-2026-05-02T06-32-08-433Z issue:#31 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## When a feature has multiple detection modes, defer any branch whose input signal does not yet exist

**Ship only the detection branches that are fully grounded by signals available today; leave schema fields and apply-branches for the PR that adds the missing signal.**

**Why:** Pre-building dead-code branches and registry fields (e.g., `retiredAt`, `retireReason`) for a mode that can never fire yet adds maintenance surface, misleads reviewers about feature completeness, and risks schema drift by the time the upstream signal actually ships.

**How to apply:** Before building each detection branch, confirm its input signal exists in the codebase or is delivered in the same PR. If it isn't, record the upstream gate explicitly in PR scope notes and emit zero proposals from that branch — do not stub it.

**Tells:** Issue covers two related cleanup actions (e.g., merge vs. retire); one action is gated on outcome metrics from a future issue; the temptation is to add stubs or empty schema keys "for completeness."

**Corollary:** A detection subcommand that emits zero proposals today because its signal hasn't landed is correct behavior, not a gap — document it as intentional rather than apologizing for it.

<!-- run:run-2026-05-03T05-54-13-869Z issue:#54 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Deduplicate cross-module parsers into a typed util with Zod schema and smoke tests

**When two or more modules contain near-identical parsing or transformation logic, extract it into `src/util/` as a single generic typed helper rather than letting copies diverge.**

**Why:** Diverging copies accumulate subtle differences silently — a resilience fix applied to one copy is missed in the others. Four independent `parseJsonLoose` implementations had drifted from each other, meaning bugs fixed in one were still present elsewhere.

**How to apply:** On any refactor touching parsing/serialization in 2+ modules: (1) audit for duplicate logic first, (2) extract to `src/util/<helperName>.ts` with a generic `<T>` and a Zod schema parameter for runtime validation, (3) add a comprehensive smoke-test file covering all input variants (bare object, fenced-tagged, fenced-untagged, stray brace, malformed JSON, schema mismatch), (4) wire `npm test` in `package.json` and add the CI step in the same commit.

**Tells:** Multiple files each define their own `parseJson*` or `extract*` helper; they share recognizable three-candidate logic (bare / fenced-tagged / fenced-untagged) but live in separate modules; the functions have drifted in minor ways (whitespace handling, error return shape).

<!-- run:run-2026-05-04T14-37-10-004Z issue:#33 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Consolidate commit-phase steps to avoid turn exhaustion before final git commit

**After tests pass, commit within 2 turns: combine `git add` and `git commit -m "..."` in one Bash call — no interim diff reviews, no temp-file message drafts, no redundant `git status` or `git fetch` calls.**
**Why:** Agents burn turns in the cleanup phase (reviewing diffs of already-reviewed files, writing commit messages to `/tmp/`, re-running builds that just passed) and hit the 50-turn ceiling before issuing `git commit`, leaving complete, tested work uncommitted.
**How to apply:** The moment `npm test` (or equivalent) is green and you know which files changed, issue `git add -A && git commit -m "<message>"` immediately — one Bash call. Don't split staging, committing, and verification across separate turns.
**Tells:** Last tool calls show ≥3 consecutive git diff / git status / git fetch / Write-to-/tmp/ calls with no `git commit` issued — the agent is in stall-loop review mode after implementation is already done.
**Guard rule:** Never write a commit message to a temp file; write it inline. Never re-run a build that just passed clean. If you catch yourself doing either, skip straight to the commit call.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#98 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Prefer `maxBudgetUsd` over `maxTurns` as the primary SDK pass stop criterion

**Never use a hardcoded `maxTurns` as a cost proxy in `runSdkPass()` calls.** Supply `maxBudgetUsd: tracker.remainingBudget()` instead, drawn from the run-level `RunCostTracker`.

**Why:** A hardcoded turn ceiling fires at a semantically arbitrary mid-edit boundary. A 9-file plan twice hit `error_max_turns` mid-edit despite forward progress, burning ~$8.30 with no recovered work. The budget ceiling fires at the same dollar threshold but at a cleaner stop point.

**How to apply:** Every `runSdkPass()` call — pass 1 AND all recovery passes — must read `tracker.remainingBudget()` so they share one budget envelope across the full run. Re-read the tracker *after* each pass so subsequent passes see the residual, not the pre-pass budget.

**Tells:** Any `runSdkPass()` with a literal `maxTurns` value; any recovery pass that resets turn count rather than reading residual budget.

**Also:** Extend recovery-trigger logic to catch `error_max_budget_usd` alongside `error_max_turns` — budget exhaustion mid-edit deserves the same truncation-recovery treatment as a turn-count stop.

<!-- promote-candidate:coding-agent -->
In the VaultPilot SDK, `maxTurns` and `maxBudgetUsd` are independent query-level constraints. Using `maxTurns` as a cost proxy causes abrupt mid-edit stops at semantically arbitrary turn boundaries. Threading `RunCostTracker.remainingBudget()` into every pass (main + recovery) as `maxBudgetUsd` gives a shared cost envelope across the full run and fires at a cleaner boundary. Recovery triggers should handle `error_max_budget_usd` the same way they handle `error_max_turns`.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T22-51-54-224Z issue:#176 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## CLI review-gate commands must default to prose diffs, not just summary metrics

**When a CLI subcommand feeds a human review step before an irreversible action (`--apply`, `--confirm`), its default output must include a prose diff — not only a byte-savings count or aggregate score.**

**Why:** A byte-savings figure cannot answer 'is this rewrite correct?' Operators silently rubber-stamp the confirm-token when the output gives them nothing actionable to inspect. This failure mode directly blocked Phase B (`--apply`) adoption for `tighten-claude-md`.

**How to apply:** Any command pair of the form *propose → apply* or *preview → confirm* falls under this rule. Wire the diff on by default; provide `--no-diff` as the opt-out for batch or scripted callers.

**Tells:** subcommand output contains a count/score metric; a sibling `--apply` or confirm-token flag exists in the same flow; issue or tags include `operator-review`.

- `--json` mode is exempted — keep JSON payloads lean; JSON consumers can reconstruct diffs from source bodies if needed.
- Cap diff body lines (≈60) to avoid wall-of-text on large rewrites; fall back to summary-only below a minimum savings floor (≈50 bytes).
- For line-oriented content (CLAUDE.md sections), prefer LCS-based line diff over word diff.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#55 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify all named prerequisites are merged before implementing dependency-gated issues

**Rule:** When an issue explicitly defers to another (e.g. 'pick up after #N lands'), check *every* prerequisite — the blocking issue AND any data-source or infrastructure PRs it depends on — are merged to `main` before writing a single line of implementation code.

**Why:** Implementing half of a multi-part feature (e.g. surfacing triage cost with no projected-dispatch-cost anchor) can land a worse UX than doing nothing — partial cost surfaces, inconsistent UI rows, or silent scope expansion into undesigned territory.

**How to apply:** On any issue that contains phrases like 'depends on', 'pick up after', 'blocked by', or lists a sibling issue number in its body, run `gh issue view <dep>` and `gh pr list` to confirm merged state before proceeding. If any named dependency is still OPEN or its PR is unmerged, post a pushback with the specific gap and ask the user to choose: hold, expand scope, or accept a flagged skeleton.

**Tells:**
- Issue title or body contains 'depends on #N' or equivalent
- A data-source PR (e.g. one introducing a new field consumed by this issue) exists but is unmerged
- The issue describes UI output that requires a value only another issue's code will produce

<!-- run:run-2026-05-05T20-46-43-739Z issue:#161 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Remediation hints must pre-check the target command's own eligibility before surfacing

**When a warning or diagnostic surfaces a 'run `vp-dev X <id>`' line, the formatting code must evaluate X's own hard preconditions — not only the caller's threshold — before choosing that branch of text.**

**Why:** The overload detector (CLAUDE.md >= 30 KB OR tags >= 50 OR issuesHandled >= 20) and the splitter clusterer (attributable sections >= `SPLIT_MIN_SECTIONS`) are independent; the pre-dispatch preview told operators to run `vp-dev agents split` for agents the splitter would refuse with 'Too few attributable sections (<4) to cluster meaningfully.' 4 of 5 flagged agents hit a dead-end UX.

**How to apply:** Any time a `formatXPreview` or status-formatter adds a remediation line, import and evaluate the target command's eligibility constant (e.g., `SPLIT_MIN_SECTIONS`) before selecting that branch. Fall through to an alternate path (e.g., compaction) when eligibility fails. Consolidate the floor into a single named export so both the command and the formatter share one source of truth.

**Tells:** Two subsystems with separate boolean thresholds; a hint that names a follow-up CLI command; that command has its own hard precondition that is NOT a subset of the caller's threshold.

<!-- promote-candidate:splitter-eligibility -->
The overload detector and the splitter clusterer carry independent eligibility criteria. An agent can exceed the overload threshold (CLAUDE.md >= 30 KB OR tags >= 50 OR issuesHandled >= 20) without meeting the splitter's hard floor (attributable sections >= SPLIT_MIN_SECTIONS, currently 4). Pre-dispatch preview code that surfaces a split hint without checking attributableSections will send operators to a command that hard-refuses. The fix is to extend the overload verdict with attributableSections and branch the remediation text at the formatter layer, using a single exported constant shared between split.ts and setup.ts.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T22-03-52-041Z issue:#168 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Relax a safety floor via an explicit opt-in flag, never by changing the default

**When an operator requests a lower threshold than an established safety floor, add a per-invocation opt-in flag — do not change the default.** The safe default exists to protect unattended / automated runs; changing it creates silent regression risk for every existing caller.

**Why:** A prior incident (floor raised from 2→3 because 2 was too aggressive for unattended compaction) is the historical contract behind the default. New feature requests that want the lower value are legitimate but must opt in explicitly so that unattended pipelines are unaffected.

**How to apply:** (1) Export the alternative floor as a named constant (e.g. `PAIR_CLUSTER_FLOOR = 2`). (2) Centralize all floor-resolution logic in a single exported helper (e.g. `resolveMinClusterSize({minClusterSize, allowPairClusters})`). (3) The helper owns the precedence table; CLI and tests both import from it. (4) The existing human-in-the-loop gate (`--apply`/`--confirm`) stays untouched — it is orthogonal to threshold relaxation.

**Tells:** issue text says "opt-in for clean cases", "support size=N when default is M", or "lower threshold for a specific scenario".

<!-- promote-candidate:operator-opt-in -->
When a CLI safety floor (e.g. min-cluster-size=3) was established to prevent aggressive behavior in unattended runs, requests to lower it are implemented as an explicit per-invocation opt-in flag rather than a default change. The floor values are exported as named constants (PAIR_CLUSTER_FLOOR, DEFAULT_MIN_CLUSTER_SIZE), and a single exported resolver function owns the precedence table. This keeps the safe default intact for all automated callers while giving operators a documented escape hatch.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T22-51-54-224Z issue:#175 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## When a clamp embeds a sentinel truncation marker, validate for it before every write path

**When a schema-validation clamp silently embeds a literal sentinel string (e.g., `\n[…truncated]`) to keep a field within a byte cap, that sentinel is a reliable detection signal — scan for it explicitly in a downstream validator before any write/apply gate fires.**

**Why:** `clampClusterFields` kept JSON valid by truncating `proposedBody`/`rationale` and appending a literal marker, but no gate checked for the marker before `applyCompaction` wrote the file, so the artifact silently persisted to disk on `--apply`.

**How to apply:** Whenever a pipeline has a clamping step that adds a detectable marker, add a `findXxx` validator that surfaces detections as a new discriminated-union `CompactionWarning` kind and piggybacks on the existing `warnings.length > 0` refusal gate — no parallel refusal mechanism needed. Also raise the byte cap alongside the refusal fix so the trigger rate drops immediately.

**Tells:** a `clamp*` / `truncate*` helper that appends a hard-coded string to signal overflow; a write path (`applyCompaction`, atomic-rename, etc.) downstream of the clamp with no intervening sentinel check.

<!-- promote-candidate:compact-claude-md -->
`clampClusterFields` (compactClaudeMd) and the analogous clamp in `tightenClaudeMd` both use the same literal marker `\n[…truncated]` to signal a truncated body. Any downstream write path that does not scan for this marker will silently persist the marker to disk. The marker is detectable as a simple `.endsWith("\n[\u2026truncated]")` check on each string field after LLM output is parsed.
<!-- /promote-candidate -->

**Note on tests:** accessing variant-specific fields on a discriminated-union warning requires a type-narrowing guard (`if (w.kind !== "expected-kind") return;`) before the field access, or TypeScript rejects the test at compile time.

<!-- run:run-2026-05-04T14-37-10-004Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Thread-through parameter changes exhaust turn budget when edited site-by-site

**When plumbing a new option end-to-end (CLI flag → interface → parse → propagate → runtime use), enumerate every change site up front and batch all edits into the fewest possible tool calls before touching any file.**

**Why:** Each granular Edit call costs one turn. A 5-site thread-through (option declaration, interface field, profile merge, run-params spread, logger log) plus build + test + commit + push + PR creation requires ~15 turns at minimum. Executing those same changes as N small targeted edits can consume 35+ turns, leaving no budget for the finalization steps — agent crashes at "all tests pass, committing" with zero turns left.

**How to apply:** On any issue whose title implies adding a flag, limit, ceiling, or config knob: (1) read all relevant files first, (2) write a mental edit plan listing every location, (3) apply each file's changes in a single large Edit or Write, never one field at a time. Reserve at least 8 turns for build → test → commit → push → PR before making the first code change.

**Tells:** Issue title contains "ceiling", "limit", "option", "per-run", "config"; implementation touches a CLI parser, a typed options interface, and one or more downstream call sites — the combination signals a multi-site thread-through.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#84 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Multi-file flag propagation exhausts turn budget when edits are piecemeal

**When threading a new CLI flag through 5+ files, prefer full-file `Write` or large batched `Edit` calls over many small sequential edits.**

**Why:** Each `Edit` is a turn; a flag that propagates through CLI → interface → orchestrator → state → preview can require 20–30 edits before the first build check, burning most of the 50-turn budget and leaving no room for compilation errors or iteration.

**How to apply:** Before starting, enumerate every file to touch and estimate edits per file. If total estimated edits > 20, switch to full-file `Write` for the most-edited files. Alternatively, widen `old_string` to capture and replace an entire function signature or interface block in one call instead of editing one field at a time.

**Tells:** New option added to a shared interface that also appears in CLI opts, orchestrator params, dispatcher args, state serialization, and a preview formatter — classic fan-out propagation where each layer needs its own edit.

<!-- run:run-2026-05-03T05-54-13-869Z issue:#62 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Commit-push-envelope must be consecutive turns; pre-commit verification burns kill the envelope

**After `git push` succeeds, emit the decision envelope in the very next turn — no intervening reads, greps, or build re-checks.**

**Why:** Agents that front-load exhaustive verification (build → typecheck → test → grep wiring checks) before the final commit+push consume most of the 50-turn budget. The push lands on turn 49 and there is no turn left to emit the envelope. The SDK sees an unfinished run and records a crash, discarding all the work even though the branch was pushed.

**How to apply:** Treat the final sequence as atomic and inviolable: `git add/commit` → `git push` → emit envelope. If optional validation (typecheck, test, grep cross-checks) hasn't been done yet, skip it rather than defer the envelope. The pushed branch is recoverable; a missing envelope is not.

**Tells:** Five or more of build/typecheck/test/grep calls appearing in the last 15 turns before the first commit attempt signals the budget is almost gone — stop verifying and push immediately.

**Corollary:** If the issue fix requires iterative build-fix cycles, do them in the first half of the turn budget. Reserve the second half for commit + push + envelope only.

<!-- run:run-2026-05-04T14-08-59-410Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Batch multi-site edits into one Write per file to avoid turn-ceiling exhaustion on feature work

**When implementing a feature that touches many locations in a file, consolidate all changes into a single `Write` (full-file replacement) or the fewest possible `Edit` calls — never one `Edit` per change site.**

**Why:** The 50-turn SDK ceiling is consumed by granular per-hunk edits before implementation, tests, and CI verification can complete, causing the agent to crash without emitting an envelope. The pattern is self-defeating: the more carefully the agent edits, the less likely it finishes.

**How to apply:** Before touching a file, enumerate every change site; write them all in one pass. If turn count passes 30 with build/test not yet green, switch immediately to `Write` for each remaining file rather than continuing surgical edits.

**Tells:**
- 5+ sequential `Edit` calls to the same file in the visible tool log
- `npm run build` / `npm test` not reached until the final 2 turns
- Agent still adding interface fields or CLI options after turn 40

**Corollary:** For features requiring new CLI flags + new interfaces + new logic + new tests, treat each file as one atomic unit of work — read the full file, plan all changes mentally, write it once.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#86 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Create the PR immediately after push — post-push verification burns turns needed for the deliverable

**After `git push` succeeds, call `gh pr create` as the very next action — before any `git log`, `git show --stat`, or `gh pr list` checks.**

**Why:** Post-push verification steps (confirming commit hashes, listing PRs, inspecting file stats) consume turns without advancing toward the actual deliverable. When a turn ceiling is close, these confirmation calls prevent PR creation from completing — leaving a fully-committed, fully-pushed branch with no open PR, which recovery passes can't fix in 4 turns if they also burn turns on re-verification.

**How to apply:** Write the PR body to a temp file early in the session (right after tests pass). After push, immediately call `gh pr create --body-file`. Reserve `git log` / `gh pr list` / `git show` only as diagnostics *if* the create step itself fails or returns an error.

**Tells:** Seeing `git log --oneline`, `git show --stat`, and `gh pr list` all appearing *after* `git push` but *before* `gh pr create` is the signature of turn-exhaustion-before-delivery risk.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#52 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Log raw output on parse failure, omit it on success

**When a structured-envelope parse fails, capture the raw final text (truncated to a safe ceiling, e.g. 4KB) in the same log entry that records the failure.** On the happy path, omit the field entirely so logs aren't bloated.

**Why:** Without the raw text, diagnosing `parseError`-class failures required re-running the agent at real cost — the evidence that would explain the failure was silently discarded at log time.

**How to apply:** Any log site that records a boolean or structured `parseError` / `decodeError` field should also emit the truncated raw input that caused it, keyed as `finalText`, `rawOutput`, or similar. Reuse an existing `truncate(s, n)` helper rather than adding a new one.

**Tells:**
- A log entry carries `parseError: true` (or non-null) with no accompanying raw content
- Diagnosing a failure class requires a re-run rather than inspecting existing logs
- A `truncate` helper already exists in scope but isn't used at the error-logging call site

<!-- run:run-2026-05-02T06-32-08-433Z issue:#32 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Reuse existing sentinel formats when adding parallel output paths — extend with a new variant value

**When a plan calls for a separate sentinel or marker format for a new parallel path, prefer adding a variant value to the existing format instead.**
**Why:** A new sentinel shape forces every downstream consumer — pruner, filter, parser — to be updated simultaneously; missed updates cause silent data loss or double-processing. Extending the existing format (e.g. `outcome:failure-lesson` alongside `outcome:lesson`) leaves all current consumers compatible with zero changes and shrinks the diff surface.
**How to apply:** Before introducing a new sentinel shape, check whether the existing marker has a string/enum field that can carry a new value. Accept a wholly new format only when the semantics are genuinely incompatible with the existing shape.
**Tells:** Plan says 'introduce a separate sentinel format'; existing sentinel has a fixed `outcome:` or `type:` discriminator field; at least one downstream pruner/filter already handles the existing format.
**Corollary:** Apply the same principle to error classifiers — add an `isInfraFlake` (or equivalent noise-gate) guard on any new error-handling path so that transport / 5xx / filesystem failures that carry no learning value are silently dropped rather than producing junk output.
