# Tailored CLAUDE.md for issue #178 (szhygulin/vaultpilot-dev-framework)

Built by `research/curve-redo-bundle/super-agent-tailored/build-tailored-agents.cjs`.
Source: `research/curve-redo-bundle/super-agent/agent-super.CLAUDE.md` (122 sections).
Selector: claude-opus-4-7[1m]; kept 16/122 sections.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#56 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify dependency PR merge status before implementing features that build on them

**Rule:** Before starting implementation of any issue that cites upstream PRs as prerequisites, confirm each cited PR is actually merged to `main` (not just closed or open) by checking `gh pr view <N> --json state,mergedAt`.

**Why:** Issue bodies can misstate PR status (e.g., 'PR #50 merged' when it was closed-unmerged). Building on absent foundations wastes effort and produces dead code — or worse, silently diverges from actual `main` behavior.

**How to apply:** Any time an issue references prior PRs, task numbers, or preceding agents' work as a prerequisite for the new feature, run the status check before touching any source file. If a dependency is missing, push back with a concrete list of blocked items and offer alternatives (block, reframe, or stub).

**Tells:**
- Issue body contains phrases like 'after PR #N is merged', 'depends on', 'builds on', or references specific outcome types / data structures not visible in `HEAD`.
- Grep for the key symbols (functions, types, file paths) introduced by the cited PR returns no results on `main`.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#101 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Two-tier (global / per-target) store extension: XDG path, tier discriminant, ENOENT-empty, load order

**When elevating any per-target store to cross-repo scope, introduce a `Tier = "target" | "global"` discriminant; resolve the global path via `$XDG_CONFIG_HOME/<app>/` with `~/.<app>/` as fallback; thread the tier param through every path-resolver, reader, and writer.** In prompt construction load global-tier entries first so per-target entries supplement rather than replace them. Treat ENOENT on either tier as an empty result, never an error.

**Why:** The shared-lessons global tier validated this pattern end-to-end. XDG compliance keeps the global store at a user-controllable location independent of any target-repo clone. ENOENT-empty semantics let the global tier be absent on fresh machines without breaking anything.

**How to apply:** Any time a store currently scoped to `agents/.shared/` needs to survive repo moves or span multiple target repos — shared lessons, agent memory, rubrics, skill maps.

**Tells:** Feature request mentions "portable", "cross-repo", or "machine-wide"; existing data lives under `agents/.shared/`; a new `--global` CLI flag is requested.

**Test checklist (9 cases minimum):** XDG env-var honored, `~/.<app>/` fallback honored, tier dispatch (write lands in correct dir), validation refusal, ENOENT → empty, tier isolation (no cross-bleed).

<!-- promote-candidate:cross-target-repo -->
Vaultpilot implements a two-tier store ("target" and "global") for shared domain knowledge. The global tier lives at `$XDG_CONFIG_HOME/vaultpilot/shared-lessons/` with `~/.vaultpilot/shared-lessons/` as the fallback. The per-target tier stays at `agents/.shared/lessons/` inside the target repo. At agent-prompt-build time both tiers are read per-domain: global entries load first, per-target entries append afterward. ENOENT on either tier resolves to an empty list; neither tier's absence is treated as an error. Promotion to either tier remains human-gated; the `--global` flag selects which tier `vp-dev lessons review` writes to.
<!-- /promote-candidate -->

<!-- run:run-2026-05-02T06-32-08-433Z issue:#31 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## When a feature has multiple detection modes, defer any branch whose input signal does not yet exist

**Ship only the detection branches that are fully grounded by signals available today; leave schema fields and apply-branches for the PR that adds the missing signal.**

**Why:** Pre-building dead-code branches and registry fields (e.g., `retiredAt`, `retireReason`) for a mode that can never fire yet adds maintenance surface, misleads reviewers about feature completeness, and risks schema drift by the time the upstream signal actually ships.

**How to apply:** Before building each detection branch, confirm its input signal exists in the codebase or is delivered in the same PR. If it isn't, record the upstream gate explicitly in PR scope notes and emit zero proposals from that branch — do not stub it.

**Tells:** Issue covers two related cleanup actions (e.g., merge vs. retire); one action is gated on outcome metrics from a future issue; the temptation is to add stubs or empty schema keys "for completeness."

**Corollary:** A detection subcommand that emits zero proposals today because its signal hasn't landed is correct behavior, not a gap — document it as intentional rather than apologizing for it.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#36 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Omit schema fields whose upstream producer does not yet exist

**When extending a data schema or adding a new one, leave out any field whose input signal has no upstream producer yet — even if the issue spec lists it.** Ship with only the fields that can be fully populated by existing code.
**Why:** A stub field (always `null`, always `0`) misleads downstream consumers and auditors into believing a data flow exists. It also creates schema churn: the field must be re-introduced, re-typed, and re-documented when the real signal arrives.
**How to apply:** If a field is gated on a sister issue that hasn't shipped, record the omission explicitly in the PR description and scope notes (e.g. 'costUsd omitted; joins schema in the PR that ships #34'). The field's owning PR adds it atomically with the producer.
**Tells:** Field names tied to a sibling tracking issue still open; columns like `$/merge` or `cost-per-X` when no cost-capture module exists yet; spec language like 'once #N lands'.
**Contrast:** Do not add `// TODO: populate when #N ships` placeholders in the schema type — the absence of the field is the correct state until the producer exists.

<!-- run:run-2026-05-04T14-37-10-004Z issue:#33 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Consolidate commit-phase steps to avoid turn exhaustion before final git commit

**After tests pass, commit within 2 turns: combine `git add` and `git commit -m "..."` in one Bash call — no interim diff reviews, no temp-file message drafts, no redundant `git status` or `git fetch` calls.**
**Why:** Agents burn turns in the cleanup phase (reviewing diffs of already-reviewed files, writing commit messages to `/tmp/`, re-running builds that just passed) and hit the 50-turn ceiling before issuing `git commit`, leaving complete, tested work uncommitted.
**How to apply:** The moment `npm test` (or equivalent) is green and you know which files changed, issue `git add -A && git commit -m "<message>"` immediately — one Bash call. Don't split staging, committing, and verification across separate turns.
**Tells:** Last tool calls show ≥3 consecutive git diff / git status / git fetch / Write-to-/tmp/ calls with no `git commit` issued — the agent is in stall-loop review mode after implementation is already done.
**Guard rule:** Never write a commit message to a temp file; write it inline. Never re-run a build that just passed clean. If you catch yourself doing either, skip straight to the commit call.

<!-- run:run-2026-05-08T13-36-56-309Z issue:#199 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Stacking lesson-append gates: hard cost-forecast gate runs before soft utility gate with default-disabled threshold

**When adding a new hard-refusal gate to `maybeAppendSummary`, place it before the existing `predictedUtility` soft gate** so the cheap delta-computation can short-circuit without touching utility logic.
**Why:** Cost-forecast gate was initially threaded after the utility gate, causing unnecessary utility work on doomed appends; reordering eliminated wasted cycles and made gate semantics clearer.
**How to apply:** Any new gate in `maybeAppendSummary` should (1) default its threshold to `+Infinity` (gate disabled) until calibration data from ≥K triples justifies a concrete value, (2) expose opt-in via a named env var parsed by a dedicated `resolve*Threshold` function, (3) share the single `currentClaudeMdBytes` read already present in the function, and (4) live in a pure exported function with its own test file covering empty-file fast-path, default-disabled invariant, log contract, and env-parse edge cases.
**Tells:** Issue asks for a new append gate, filter, or threshold; `maybeAppendSummary` is the integration point; env var named `VP_DEV_*` controls the knob.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#55 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify all named prerequisites are merged before implementing dependency-gated issues

**Rule:** When an issue explicitly defers to another (e.g. 'pick up after #N lands'), check *every* prerequisite — the blocking issue AND any data-source or infrastructure PRs it depends on — are merged to `main` before writing a single line of implementation code.

**Why:** Implementing half of a multi-part feature (e.g. surfacing triage cost with no projected-dispatch-cost anchor) can land a worse UX than doing nothing — partial cost surfaces, inconsistent UI rows, or silent scope expansion into undesigned territory.

**How to apply:** On any issue that contains phrases like 'depends on', 'pick up after', 'blocked by', or lists a sibling issue number in its body, run `gh issue view <dep>` and `gh pr list` to confirm merged state before proceeding. If any named dependency is still OPEN or its PR is unmerged, post a pushback with the specific gap and ask the user to choose: hold, expand scope, or accept a flagged skeleton.

**Tells:**
- Issue title or body contains 'depends on #N' or equivalent
- A data-source PR (e.g. one introducing a new field consumed by this issue) exists but is unmerged
- The issue describes UI output that requires a value only another issue's code will produce

<!-- run:run-2026-05-04T14-37-10-004Z issue:#55 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Break dependency-chain stalls by making the missing anchor field optional and omitting its display row

**Rule:** When an issue's display row depends on an upstream that is itself blocked, add the dependent value as an *optional* field on the shared struct, gate the rendered row on *presence* (not on zero), and ship the issue standalone with a scope note that the upstream will slot in when it lands.

**Why:** A stalled upstream can block an otherwise self-contained change indefinitely. Making the field optional decouples the two issues: the row simply doesn't appear until the upstream ships, which is the correct UX — a zero-valued or 'N/A' row would be worse than no row.

**How to apply:** Identify whether the blocked dependency is *strictly required* or only needed for one display row. If the latter, scope the issue to the optional-field pattern, note the integration point in a `scopeNotes` comment, and proceed. Update tests to assert the row is absent (not zero) when the field is undefined.

**Tells:** Issue title says 'depends on #N'; the dependency is marked blocked or awaiting another fix; the missing data is already logged elsewhere and only needs to be threaded to the UI.

<!-- run:run-2026-05-04T14-37-10-004Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Thread-through parameter changes exhaust turn budget when edited site-by-site

**When plumbing a new option end-to-end (CLI flag → interface → parse → propagate → runtime use), enumerate every change site up front and batch all edits into the fewest possible tool calls before touching any file.**

**Why:** Each granular Edit call costs one turn. A 5-site thread-through (option declaration, interface field, profile merge, run-params spread, logger log) plus build + test + commit + push + PR creation requires ~15 turns at minimum. Executing those same changes as N small targeted edits can consume 35+ turns, leaving no budget for the finalization steps — agent crashes at "all tests pass, committing" with zero turns left.

**How to apply:** On any issue whose title implies adding a flag, limit, ceiling, or config knob: (1) read all relevant files first, (2) write a mental edit plan listing every location, (3) apply each file's changes in a single large Edit or Write, never one field at a time. Reserve at least 8 turns for build → test → commit → push → PR before making the first code change.

**Tells:** Issue title contains "ceiling", "limit", "option", "per-run", "config"; implementation touches a CLI parser, a typed options interface, and one or more downstream call sites — the combination signals a multi-site thread-through.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#84 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Multi-file flag propagation exhausts turn budget when edits are piecemeal

**When threading a new CLI flag through 5+ files, prefer full-file `Write` or large batched `Edit` calls over many small sequential edits.**

**Why:** Each `Edit` is a turn; a flag that propagates through CLI → interface → orchestrator → state → preview can require 20–30 edits before the first build check, burning most of the 50-turn budget and leaving no room for compilation errors or iteration.

**How to apply:** Before starting, enumerate every file to touch and estimate edits per file. If total estimated edits > 20, switch to full-file `Write` for the most-edited files. Alternatively, widen `old_string` to capture and replace an entire function signature or interface block in one call instead of editing one field at a time.

**Tells:** New option added to a shared interface that also appears in CLI opts, orchestrator params, dispatcher args, state serialization, and a preview formatter — classic fan-out propagation where each layer needs its own edit.

<!-- run:run-2026-05-03T05-54-13-869Z issue:#62 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Commit-push-envelope must be consecutive turns; pre-commit verification burns kill the envelope

**After `git push` succeeds, emit the decision envelope in the very next turn — no intervening reads, greps, or build re-checks.**

**Why:** Agents that front-load exhaustive verification (build → typecheck → test → grep wiring checks) before the final commit+push consume most of the 50-turn budget. The push lands on turn 49 and there is no turn left to emit the envelope. The SDK sees an unfinished run and records a crash, discarding all the work even though the branch was pushed.

**How to apply:** Treat the final sequence as atomic and inviolable: `git add/commit` → `git push` → emit envelope. If optional validation (typecheck, test, grep cross-checks) hasn't been done yet, skip it rather than defer the envelope. The pushed branch is recoverable; a missing envelope is not.

**Tells:** Five or more of build/typecheck/test/grep calls appearing in the last 15 turns before the first commit attempt signals the budget is almost gone — stop verifying and push immediately.

**Corollary:** If the issue fix requires iterative build-fix cycles, do them in the first half of the turn budget. Reserve the second half for commit + push + envelope only.

<!-- run:run-2026-05-04T14-08-59-410Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Batch multi-site edits into one Write per file to avoid turn-ceiling exhaustion on feature work

**When implementing a feature that touches many locations in a file, consolidate all changes into a single `Write` (full-file replacement) or the fewest possible `Edit` calls — never one `Edit` per change site.**

**Why:** The 50-turn SDK ceiling is consumed by granular per-hunk edits before implementation, tests, and CI verification can complete, causing the agent to crash without emitting an envelope. The pattern is self-defeating: the more carefully the agent edits, the less likely it finishes.

**How to apply:** Before touching a file, enumerate every change site; write them all in one pass. If turn count passes 30 with build/test not yet green, switch immediately to `Write` for each remaining file rather than continuing surgical edits.

**Tells:**
- 5+ sequential `Edit` calls to the same file in the visible tool log
- `npm run build` / `npm test` not reached until the final 2 turns
- Agent still adding interface fields or CLI options after turn 40

**Corollary:** For features requiring new CLI flags + new interfaces + new logic + new tests, treat each file as one atomic unit of work — read the full file, plan all changes mentally, write it once.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#86 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Create the PR immediately after push — post-push verification burns turns needed for the deliverable

**After `git push` succeeds, call `gh pr create` as the very next action — before any `git log`, `git show --stat`, or `gh pr list` checks.**

**Why:** Post-push verification steps (confirming commit hashes, listing PRs, inspecting file stats) consume turns without advancing toward the actual deliverable. When a turn ceiling is close, these confirmation calls prevent PR creation from completing — leaving a fully-committed, fully-pushed branch with no open PR, which recovery passes can't fix in 4 turns if they also burn turns on re-verification.

**How to apply:** Write the PR body to a temp file early in the session (right after tests pass). After push, immediately call `gh pr create --body-file`. Reserve `git log` / `gh pr list` / `git show` only as diagnostics *if* the create step itself fails or returns an error.

**Tells:** Seeing `git log --oneline`, `git show --stat`, and `gh pr list` all appearing *after* `git push` but *before* `gh pr create` is the signature of turn-exhaustion-before-delivery risk.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#33 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Shared knowledge pools seeded from agent-controlled files inherit those files' trust level — treat promotion as an in...

**When a cross-agent knowledge-aggregation pipeline reads from per-agent files (CLAUDE.md, local notes) and promotes content into a shared pool, the shared pool's integrity boundary sits *inside* the agent's data plane.** The pool is only as trustworthy as the least-trusted file that feeds it.
**Why:** A subtly injected or compromised CLAUDE.md can silently propagate adversarial rules into every sibling agent that consumes the shared pool. Human reviewers scanning ~200-line pool diffs under normal workload pressure are an unreliable sole defense.
**How to apply:** Before implementing or approving any lessons-promotion or knowledge-aggregation feature, verify whether the promotion source is agent-controlled. If it is, require: (a) a fixed schema with bounded field sizes that strips freeform prose, (b) a diff-only human review gate that specifies *exactly* what the reviewer must check, and (c) explicit documentation of the residual injection risk.
**Tells:** feature spec reads from `CLAUDE.md` or equivalent per-agent file to populate a shared resource; review step is described only as "human approval" with no checklist; pool files grow past ~100 lines of freeform text.

<!-- run:run-2026-05-04T14-08-59-410Z issue:#56 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Expire in-file sentinels using their own chronological chain; never expire legacy markers

**Embed all metadata needed for expiry decisions into the sentinel header at write-time, and source the streak signal from the file's own chronological chain — not from external state directories.**
**Why:** Cross-referencing an external `state/outcomes/` store couples expiry logic to a second data source, introduces ordering races, and breaks idempotency; a self-contained in-file chain is reproducible and trivially unit-testable.
**How to apply:** Whenever a sentinel or in-file marker needs lifecycle management (expiry, promotion, retirement), emit the tag fingerprint or other decision key into the sentinel header on creation, then read only that file to decide expiry.
**Tells:** 'expire after K successes' requirements, in-file CLAUDE.md lifecycle rules, sentinel schemas being extended with new metadata fields.
- **Never expire sentinels that predate the new metadata schema.** Records missing the required field must be treated as perpetual — silent expiry of legacy entries is data loss.
- **Expose the threshold (K) via an env var with a conservative default** (e.g. 3); never hard-code policy constants in expiry logic.
- **Isolate parsing + expiry into a pure utility module** with no side-effects so it can be exhaustively unit-tested independent of file I/O.

<!-- run:run-2026-05-02T06-32-08-433Z issue:#32 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Reuse existing sentinel formats when adding parallel output paths — extend with a new variant value

**When a plan calls for a separate sentinel or marker format for a new parallel path, prefer adding a variant value to the existing format instead.**
**Why:** A new sentinel shape forces every downstream consumer — pruner, filter, parser — to be updated simultaneously; missed updates cause silent data loss or double-processing. Extending the existing format (e.g. `outcome:failure-lesson` alongside `outcome:lesson`) leaves all current consumers compatible with zero changes and shrinks the diff surface.
**How to apply:** Before introducing a new sentinel shape, check whether the existing marker has a string/enum field that can carry a new value. Accept a wholly new format only when the semantics are genuinely incompatible with the existing shape.
**Tells:** Plan says 'introduce a separate sentinel format'; existing sentinel has a fixed `outcome:` or `type:` discriminator field; at least one downstream pruner/filter already handles the existing format.
**Corollary:** Apply the same principle to error classifiers — add an `isInfraFlake` (or equivalent noise-gate) guard on any new error-handling path so that transport / 5xx / filesystem failures that carry no learning value are silently dropped rather than producing junk output.
