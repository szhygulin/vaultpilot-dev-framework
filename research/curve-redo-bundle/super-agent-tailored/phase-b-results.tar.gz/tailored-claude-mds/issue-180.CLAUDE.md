# Tailored CLAUDE.md for issue #180 (szhygulin/vaultpilot-dev-framework)

Built by `research/curve-redo-bundle/super-agent-tailored/build-tailored-agents.cjs`.
Source: `research/curve-redo-bundle/super-agent/agent-super.CLAUDE.md` (122 sections).
Selector: claude-opus-4-7[1m]; kept 13/122 sections.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#56 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify dependency PR merge status before implementing features that build on them

**Rule:** Before starting implementation of any issue that cites upstream PRs as prerequisites, confirm each cited PR is actually merged to `main` (not just closed or open) by checking `gh pr view <N> --json state,mergedAt`.

**Why:** Issue bodies can misstate PR status (e.g., 'PR #50 merged' when it was closed-unmerged). Building on absent foundations wastes effort and produces dead code — or worse, silently diverges from actual `main` behavior.

**How to apply:** Any time an issue references prior PRs, task numbers, or preceding agents' work as a prerequisite for the new feature, run the status check before touching any source file. If a dependency is missing, push back with a concrete list of blocked items and offer alternatives (block, reframe, or stub).

**Tells:**
- Issue body contains phrases like 'after PR #N is merged', 'depends on', 'builds on', or references specific outcome types / data structures not visible in `HEAD`.
- Grep for the key symbols (functions, types, file paths) introduced by the cited PR returns no results on `main`.

<!-- run:run-2026-05-02T06-32-08-433Z issue:#31 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## When a feature has multiple detection modes, defer any branch whose input signal does not yet exist

**Ship only the detection branches that are fully grounded by signals available today; leave schema fields and apply-branches for the PR that adds the missing signal.**

**Why:** Pre-building dead-code branches and registry fields (e.g., `retiredAt`, `retireReason`) for a mode that can never fire yet adds maintenance surface, misleads reviewers about feature completeness, and risks schema drift by the time the upstream signal actually ships.

**How to apply:** Before building each detection branch, confirm its input signal exists in the codebase or is delivered in the same PR. If it isn't, record the upstream gate explicitly in PR scope notes and emit zero proposals from that branch — do not stub it.

**Tells:** Issue covers two related cleanup actions (e.g., merge vs. retire); one action is gated on outcome metrics from a future issue; the temptation is to add stubs or empty schema keys "for completeness."

**Corollary:** A detection subcommand that emits zero proposals today because its signal hasn't landed is correct behavior, not a gap — document it as intentional rather than apologizing for it.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#36 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Omit schema fields whose upstream producer does not yet exist

**When extending a data schema or adding a new one, leave out any field whose input signal has no upstream producer yet — even if the issue spec lists it.** Ship with only the fields that can be fully populated by existing code.
**Why:** A stub field (always `null`, always `0`) misleads downstream consumers and auditors into believing a data flow exists. It also creates schema churn: the field must be re-introduced, re-typed, and re-documented when the real signal arrives.
**How to apply:** If a field is gated on a sister issue that hasn't shipped, record the omission explicitly in the PR description and scope notes (e.g. 'costUsd omitted; joins schema in the PR that ships #34'). The field's owning PR adds it atomically with the producer.
**Tells:** Field names tied to a sibling tracking issue still open; columns like `$/merge` or `cost-per-X` when no cost-capture module exists yet; spec language like 'once #N lands'.
**Contrast:** Do not add `// TODO: populate when #N ships` placeholders in the schema type — the absence of the field is the correct state until the producer exists.

<!-- run:run-2026-05-04T14-37-10-004Z issue:#33 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Consolidate commit-phase steps to avoid turn exhaustion before final git commit

**After tests pass, commit within 2 turns: combine `git add` and `git commit -m "..."` in one Bash call — no interim diff reviews, no temp-file message drafts, no redundant `git status` or `git fetch` calls.**
**Why:** Agents burn turns in the cleanup phase (reviewing diffs of already-reviewed files, writing commit messages to `/tmp/`, re-running builds that just passed) and hit the 50-turn ceiling before issuing `git commit`, leaving complete, tested work uncommitted.
**How to apply:** The moment `npm test` (or equivalent) is green and you know which files changed, issue `git add -A && git commit -m "<message>"` immediately — one Bash call. Don't split staging, committing, and verification across separate turns.
**Tells:** Last tool calls show ≥3 consecutive git diff / git status / git fetch / Write-to-/tmp/ calls with no `git commit` issued — the agent is in stall-loop review mode after implementation is already done.
**Guard rule:** Never write a commit message to a temp file; write it inline. Never re-run a build that just passed clean. If you catch yourself doing either, skip straight to the commit call.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#55 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify all named prerequisites are merged before implementing dependency-gated issues

**Rule:** When an issue explicitly defers to another (e.g. 'pick up after #N lands'), check *every* prerequisite — the blocking issue AND any data-source or infrastructure PRs it depends on — are merged to `main` before writing a single line of implementation code.

**Why:** Implementing half of a multi-part feature (e.g. surfacing triage cost with no projected-dispatch-cost anchor) can land a worse UX than doing nothing — partial cost surfaces, inconsistent UI rows, or silent scope expansion into undesigned territory.

**How to apply:** On any issue that contains phrases like 'depends on', 'pick up after', 'blocked by', or lists a sibling issue number in its body, run `gh issue view <dep>` and `gh pr list` to confirm merged state before proceeding. If any named dependency is still OPEN or its PR is unmerged, post a pushback with the specific gap and ask the user to choose: hold, expand scope, or accept a flagged skeleton.

**Tells:**
- Issue title or body contains 'depends on #N' or equivalent
- A data-source PR (e.g. one introducing a new field consumed by this issue) exists but is unmerged
- The issue describes UI output that requires a value only another issue's code will produce

<!-- run:run-2026-05-04T14-37-10-004Z issue:#55 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Break dependency-chain stalls by making the missing anchor field optional and omitting its display row

**Rule:** When an issue's display row depends on an upstream that is itself blocked, add the dependent value as an *optional* field on the shared struct, gate the rendered row on *presence* (not on zero), and ship the issue standalone with a scope note that the upstream will slot in when it lands.

**Why:** A stalled upstream can block an otherwise self-contained change indefinitely. Making the field optional decouples the two issues: the row simply doesn't appear until the upstream ships, which is the correct UX — a zero-valued or 'N/A' row would be worse than no row.

**How to apply:** Identify whether the blocked dependency is *strictly required* or only needed for one display row. If the latter, scope the issue to the optional-field pattern, note the integration point in a `scopeNotes` comment, and proceed. Update tests to assert the row is absent (not zero) when the field is undefined.

**Tells:** Issue title says 'depends on #N'; the dependency is marked blocked or awaiting another fix; the missing data is already logged elsewhere and only needs to be threaded to the UI.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#99 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Budget arithmetic tests: use approximate equality to avoid float-precision fix loops

**When implementing cost-estimation or budget-gate features, define a float-tolerant assertion helper before writing any test that subtracts or accumulates USD values.**

**Why:** Derived budget values like `5.0 - 3.6` evaluate to `1.3999999...` in IEEE 754; exact `assert.equal` fails, pushing the agent into a run-test → edit-assertion → run-test loop that burns turns without converging — lethal under a 50-turn ceiling.

**How to apply:** At the top of every cost/budget test file, declare a `closeEnough(a, b, tol = 0.001): boolean` helper and use it for every `remainingBudgetUsd`, `totalForecast`, or accumulated-cost assertion. Never use strict equality on a float derived from subtraction or multi-step accumulation.

**Tells:** Repeated `Edit` + `Bash npm test` alternation on the same test file; `old_string` references `remainingBudget`, `totalForecast`, or similar fields; expected vs actual values differ by < 0.01.

**Recovery heuristic:** If two successive test-fix attempts fail on the same assertion, stop and introduce the tolerance helper before any further edits — don't keep adjusting the literal value.

<!-- run:run-2026-05-05T20-46-43-739Z issue:#161 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Remediation hints must pre-check the target command's own eligibility before surfacing

**When a warning or diagnostic surfaces a 'run `vp-dev X <id>`' line, the formatting code must evaluate X's own hard preconditions — not only the caller's threshold — before choosing that branch of text.**

**Why:** The overload detector (CLAUDE.md >= 30 KB OR tags >= 50 OR issuesHandled >= 20) and the splitter clusterer (attributable sections >= `SPLIT_MIN_SECTIONS`) are independent; the pre-dispatch preview told operators to run `vp-dev agents split` for agents the splitter would refuse with 'Too few attributable sections (<4) to cluster meaningfully.' 4 of 5 flagged agents hit a dead-end UX.

**How to apply:** Any time a `formatXPreview` or status-formatter adds a remediation line, import and evaluate the target command's eligibility constant (e.g., `SPLIT_MIN_SECTIONS`) before selecting that branch. Fall through to an alternate path (e.g., compaction) when eligibility fails. Consolidate the floor into a single named export so both the command and the formatter share one source of truth.

**Tells:** Two subsystems with separate boolean thresholds; a hint that names a follow-up CLI command; that command has its own hard precondition that is NOT a subset of the caller's threshold.

<!-- promote-candidate:splitter-eligibility -->
The overload detector and the splitter clusterer carry independent eligibility criteria. An agent can exceed the overload threshold (CLAUDE.md >= 30 KB OR tags >= 50 OR issuesHandled >= 20) without meeting the splitter's hard floor (attributable sections >= SPLIT_MIN_SECTIONS, currently 4). Pre-dispatch preview code that surfaces a split hint without checking attributableSections will send operators to a command that hard-refuses. The fix is to extend the overload verdict with attributableSections and branch the remediation text at the formatter layer, using a single exported constant shared between split.ts and setup.ts.
<!-- /promote-candidate -->

<!-- run:run-2026-05-04T14-37-10-004Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Thread-through parameter changes exhaust turn budget when edited site-by-site

**When plumbing a new option end-to-end (CLI flag → interface → parse → propagate → runtime use), enumerate every change site up front and batch all edits into the fewest possible tool calls before touching any file.**

**Why:** Each granular Edit call costs one turn. A 5-site thread-through (option declaration, interface field, profile merge, run-params spread, logger log) plus build + test + commit + push + PR creation requires ~15 turns at minimum. Executing those same changes as N small targeted edits can consume 35+ turns, leaving no budget for the finalization steps — agent crashes at "all tests pass, committing" with zero turns left.

**How to apply:** On any issue whose title implies adding a flag, limit, ceiling, or config knob: (1) read all relevant files first, (2) write a mental edit plan listing every location, (3) apply each file's changes in a single large Edit or Write, never one field at a time. Reserve at least 8 turns for build → test → commit → push → PR before making the first code change.

**Tells:** Issue title contains "ceiling", "limit", "option", "per-run", "config"; implementation touches a CLI parser, a typed options interface, and one or more downstream call sites — the combination signals a multi-site thread-through.

<!-- run:run-2026-05-05T14-26-37-251Z issue:#587 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify referenced artifacts exist before acting on tooling or aggregator bug reports

**Rule:** Before writing any code or fix for a bug report that names specific files, directories, or symbols, run a repo-wide scan (grep/find/`gh search code`) to confirm those artifacts actually exist in THIS repo. If the scan returns zero hits, treat the issue as potentially misfiled rather than inventing a duplicate implementation.

**Why:** An issue naming `tools/sample_matrix_run.py` and `runs/matrix-sampled/` was filed in the wrong repo; both paths were absent repo-wide. Implementing a phantom aggregator from scratch would have created maintenance-splitting debt and diverged from the canonical logic in the sibling repo.

**How to apply:** Whenever an issue references a concrete file path, module name, or CLI entrypoint — especially in `tools/`, `scripts/`, or a named sub-command — confirm the path exists before scoping work. If it doesn't exist, push back with three options: refile in the correct repo, file a doc-only sub-issue for any vocabulary/interface contract that does belong here, or close as misfiled.

**Tells:** Issue title names a specific script or aggregator; repo has no `tools/` directory or no Python sources; referenced symbols return zero grep hits across the entire worktree.

<!-- promote-candidate:misfiled-issue -->
When a bug report names a concrete file path or script (e.g. `tools/sample_matrix_run.py`) and that path returns zero hits in a repo-wide scan, the issue is almost certainly misfiled against a sibling repo. The correct handling is pushback with three explicit options: refile in the owning repo, file a doc-only sub-issue for any shared interface contract, or close as misfiled. Creating a duplicate implementation from scratch to satisfy the issue as filed splits maintenance and diverges from canonical logic.
<!-- /promote-candidate -->

<!-- run:run-2026-05-03T05-54-13-869Z issue:#62 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Commit-push-envelope must be consecutive turns; pre-commit verification burns kill the envelope

**After `git push` succeeds, emit the decision envelope in the very next turn — no intervening reads, greps, or build re-checks.**

**Why:** Agents that front-load exhaustive verification (build → typecheck → test → grep wiring checks) before the final commit+push consume most of the 50-turn budget. The push lands on turn 49 and there is no turn left to emit the envelope. The SDK sees an unfinished run and records a crash, discarding all the work even though the branch was pushed.

**How to apply:** Treat the final sequence as atomic and inviolable: `git add/commit` → `git push` → emit envelope. If optional validation (typecheck, test, grep cross-checks) hasn't been done yet, skip it rather than defer the envelope. The pushed branch is recoverable; a missing envelope is not.

**Tells:** Five or more of build/typecheck/test/grep calls appearing in the last 15 turns before the first commit attempt signals the budget is almost gone — stop verifying and push immediately.

**Corollary:** If the issue fix requires iterative build-fix cycles, do them in the first half of the turn budget. Reserve the second half for commit + push + envelope only.

<!-- run:run-2026-05-04T14-08-59-410Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Batch multi-site edits into one Write per file to avoid turn-ceiling exhaustion on feature work

**When implementing a feature that touches many locations in a file, consolidate all changes into a single `Write` (full-file replacement) or the fewest possible `Edit` calls — never one `Edit` per change site.**

**Why:** The 50-turn SDK ceiling is consumed by granular per-hunk edits before implementation, tests, and CI verification can complete, causing the agent to crash without emitting an envelope. The pattern is self-defeating: the more carefully the agent edits, the less likely it finishes.

**How to apply:** Before touching a file, enumerate every change site; write them all in one pass. If turn count passes 30 with build/test not yet green, switch immediately to `Write` for each remaining file rather than continuing surgical edits.

**Tells:**
- 5+ sequential `Edit` calls to the same file in the visible tool log
- `npm run build` / `npm test` not reached until the final 2 turns
- Agent still adding interface fields or CLI options after turn 40

**Corollary:** For features requiring new CLI flags + new interfaces + new logic + new tests, treat each file as one atomic unit of work — read the full file, plan all changes mentally, write it once.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#86 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Create the PR immediately after push — post-push verification burns turns needed for the deliverable

**After `git push` succeeds, call `gh pr create` as the very next action — before any `git log`, `git show --stat`, or `gh pr list` checks.**

**Why:** Post-push verification steps (confirming commit hashes, listing PRs, inspecting file stats) consume turns without advancing toward the actual deliverable. When a turn ceiling is close, these confirmation calls prevent PR creation from completing — leaving a fully-committed, fully-pushed branch with no open PR, which recovery passes can't fix in 4 turns if they also burn turns on re-verification.

**How to apply:** Write the PR body to a temp file early in the session (right after tests pass). After push, immediately call `gh pr create --body-file`. Reserve `git log` / `gh pr list` / `git show` only as diagnostics *if* the create step itself fails or returns an error.

**Tells:** Seeing `git log --oneline`, `git show --stat`, and `gh pr list` all appearing *after* `git push` but *before* `gh pr create` is the signature of turn-exhaustion-before-delivery risk.
