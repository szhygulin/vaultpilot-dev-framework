# Tailored CLAUDE.md for issue #185 (szhygulin/vaultpilot-dev-framework)

Built by `research/curve-redo-bundle/super-agent-tailored/build-tailored-agents.cjs`.
Source: `research/curve-redo-bundle/super-agent/agent-super.CLAUDE.md` (122 sections).
Selector: claude-opus-4-7[1m]; kept 17/122 sections.

<!-- run:run-2026-05-02T06-32-08-433Z issue:#35 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## LLM pre-flight classification gates: lightweight model, content-hash cache, fail-open, bypass flag

**When adding an LLM-driven gate that filters or classifies items before dispatch, follow four invariants together: use a cheap/fast model, cache by content hash, fail open, and ship a bypass flag in the same PR.**

**Why:** Pre-flight classification is called once per item on every run; using the full model wastes tokens, re-classifying unchanged issues wastes latency, a broken API call must never silently drop work, and operators need an escape hatch without code changes.

**How to apply:** Any time an LLM call is introduced as a gate (triage, duplicate detection, readiness check, etc.) before the main dispatch loop.

**Tells:** New `triage`, `classify`, or `filter` step inserted before work is dispatched; issues or items can be dropped/skipped based on the result.

- **Model:** prefer `claude-haiku-*` (or equivalent cheapest tier) for yes/no or enum classification rubrics.
- **Cache key:** SHA-256 of the input content (body + comments, query text, etc.); store at a stable path like `state/<feature>/<repo>/<id>.json`; skip the API call on a hit.
- **Fail-open:** if the classification call throws or returns an unexpected shape, treat the item as passing — never let a broken pre-flight silently discard work.
- **Bypass flag:** add a `--include-<thing>` or `--skip-<gate>` CLI flag in the same commit so the gate can be disabled without code changes.
- **Pipeline position:** insert the gate *after* range resolution and *before* the approval gate so skipped items surface in the user-visible preview.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#56 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify dependency PR merge status before implementing features that build on them

**Rule:** Before starting implementation of any issue that cites upstream PRs as prerequisites, confirm each cited PR is actually merged to `main` (not just closed or open) by checking `gh pr view <N> --json state,mergedAt`.

**Why:** Issue bodies can misstate PR status (e.g., 'PR #50 merged' when it was closed-unmerged). Building on absent foundations wastes effort and produces dead code — or worse, silently diverges from actual `main` behavior.

**How to apply:** Any time an issue references prior PRs, task numbers, or preceding agents' work as a prerequisite for the new feature, run the status check before touching any source file. If a dependency is missing, push back with a concrete list of blocked items and offer alternatives (block, reframe, or stub).

**Tells:**
- Issue body contains phrases like 'after PR #N is merged', 'depends on', 'builds on', or references specific outcome types / data structures not visible in `HEAD`.
- Grep for the key symbols (functions, types, file paths) introduced by the cited PR returns no results on `main`.

<!-- run:run-2026-05-04T14-08-59-410Z issue:#67 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Triage rubrics must distinguish irreconcilable conflicts from transient dependency signals

**When a triage rubric checks for body/comments conflicts, treat only *permanent* conflict signals as skip conditions — never transient upstream-dependency language.**

**Why:** A comment saying 'blocked on PR #N' or 'depends on #M' is a point-in-time state, not a verdict on the issue itself. The dispatched coding agent re-reads comments at runtime and can push back or proceed once the dependency lands. Skipping at triage throws away valid work and hides the issue from the queue indefinitely.

**How to apply:** When editing or writing a triage prompt's rubric, partition conflict signals into two explicit buckets:
- *Skip (irreconcilable):* obsolete, superseded, won't-fix, redirects to a still-open true duplicate, premise explicitly invalidated by comments.
- *Pass through (transient):* 'blocked on PR #N', 'depends on #M', 'waiting for upstream', 'gated on another issue'.

**Tells:**
- Rubric has a catch-all 'body and comments conflict → skip' clause.
- Issue is upstream-gated or tagged `upstream-tracking` / `upstream-gated`.
- The dispatched agent already has a global 're-read comments before acting' rule.

**How to apply (implementation):** A prompt-only edit to the rubric is sufficient — no orchestrator code changes needed. List the irreconcilable signals explicitly so the model does not overgeneralize.

<!-- run:run-2026-05-02T06-32-08-433Z issue:#31 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## When a feature has multiple detection modes, defer any branch whose input signal does not yet exist

**Ship only the detection branches that are fully grounded by signals available today; leave schema fields and apply-branches for the PR that adds the missing signal.**

**Why:** Pre-building dead-code branches and registry fields (e.g., `retiredAt`, `retireReason`) for a mode that can never fire yet adds maintenance surface, misleads reviewers about feature completeness, and risks schema drift by the time the upstream signal actually ships.

**How to apply:** Before building each detection branch, confirm its input signal exists in the codebase or is delivered in the same PR. If it isn't, record the upstream gate explicitly in PR scope notes and emit zero proposals from that branch — do not stub it.

**Tells:** Issue covers two related cleanup actions (e.g., merge vs. retire); one action is gated on outcome metrics from a future issue; the temptation is to add stubs or empty schema keys "for completeness."

**Corollary:** A detection subcommand that emits zero proposals today because its signal hasn't landed is correct behavior, not a gap — document it as intentional rather than apologizing for it.

<!-- run:run-2026-05-04T14-37-10-004Z issue:#33 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Consolidate commit-phase steps to avoid turn exhaustion before final git commit

**After tests pass, commit within 2 turns: combine `git add` and `git commit -m "..."` in one Bash call — no interim diff reviews, no temp-file message drafts, no redundant `git status` or `git fetch` calls.**
**Why:** Agents burn turns in the cleanup phase (reviewing diffs of already-reviewed files, writing commit messages to `/tmp/`, re-running builds that just passed) and hit the 50-turn ceiling before issuing `git commit`, leaving complete, tested work uncommitted.
**How to apply:** The moment `npm test` (or equivalent) is green and you know which files changed, issue `git add -A && git commit -m "<message>"` immediately — one Bash call. Don't split staging, committing, and verification across separate turns.
**Tells:** Last tool calls show ≥3 consecutive git diff / git status / git fetch / Write-to-/tmp/ calls with no `git commit` issued — the agent is in stall-loop review mode after implementation is already done.
**Guard rule:** Never write a commit message to a temp file; write it inline. Never re-run a build that just passed clean. If you catch yourself doing either, skip straight to the commit call.

<!-- run:run-2026-05-05T16-51-01-872Z issue:#133 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## When an issue body self-proposes a phase split, treat that split as mandatory at pre-dispatch

**When an issue body contains an explicit phase-split or 'Suggested implementation split' section, push back on the combined scope — the split is mandatory, not advisory.**

**Why:** Issue authors who pre-propose splits have already diagnosed over-scoping; dispatching the combined scope burns turns on a predictable rejection and duplicates the author's own analysis.

**How to apply:** During pre-dispatch scope-fit check, scan the issue body for phase-split language ('Phase 1/2', 'Suggested split', 'dependency seam', 'imports X constant'). Evaluate each phase independently against the 5-file threshold (with 1.5× calibration). Name the dependency seam explicitly in the pushback comment and recommend filing as sequential issues, citing any prior split pattern (e.g., #34 → #85+#86) as precedent.

**Tells:** 'Phase 1', 'Phase 2', 'Suggested implementation split', 'clean dependency seam', 'imports [Phase 1 export]' anywhere in the issue body.

**Bonus sweep:** Grep `src/` for the relevant model/constant patterns during scope inspection — issue authors routinely miss 1–2 files that belong in Phase 1's migration list. Name them in the pushback so re-filed issues are complete from the start.

<!-- promote-candidate:pre-dispatch-scope-fit -->
Issue bodies that contain explicit 'Phase 1 / Phase 2' or 'Suggested implementation split' sections reliably signal that the combined scope exceeds the per-issue budget. Each such issue tends to have a named dependency seam (e.g., Phase 2 imports a constant exported by Phase 1). The combined stated file count, after the 1.5x under-count calibration, consistently lands above the 5-file pre-dispatch threshold. Grepping source files for the relevant model/constant patterns during scope inspection typically surfaces 1–2 additional files the issue author omitted; these belong in the first phase's migration list. Recommending sequential issue filing with the dependency seam named in the pushback comment is the correct resolutio
[…truncated]

<!-- run:run-2026-05-05T22-03-52-041Z issue:#169 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Self-proposed phase split in an issue body is a mandatory scope boundary

**When an issue body itself proposes a Phase A / Phase B split with a named dependency seam, that self-proposed split is mandatory — push back and require two sequential issues before any implementation begins.**
**Why:** An author who names the sequencing dependency inside the combined issue is signaling scope overload. Bundling both phases in one dispatch defeats the stated precondition (e.g., the advisory dry-run must exercise real agent files before the destructive `--apply` sibling ships), and prior compact-feature precedent shows a single phase alone produces 700–800 lines of source + test.
**How to apply:** At pre-dispatch, scan the issue body for self-proposed splits. If a dependency is named — especially advisory-before-destructive — push back regardless of apparent implementation size or the author's intent to 'just combine them for convenience'.
**Tells:** Phrases like 'Phase A / Phase B', 'advisory predecessor', 'don't repeat the mistake of shipping the destructive sibling', or paired `--dry-run` / `--apply` with an explicit ordering note anywhere in the body.

<!-- promote-candidate:advisory-then-destructive -->
When a feature issue bundles an advisory (dry-run / read-only) phase with a destructive (write / apply) phase and explicitly names the sequencing dependency in its own body, the combined dispatch consistently fails the pre-dispatch scope-fit check. The advisory phase must be dispatched, merged, and exercised on real agent files before the destructive sibling is filed as a separate issue — not merely described as a future concern. A single advisory phase alone in this codebase has produced 700–800 lines of source and test; bundling both phases roughly doubles that before any safety validation has occurred on live data.
<!-- /promote-candidate -->

<!-- run:run-2026-05-02T10-31-33-192Z issue:#55 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify all named prerequisites are merged before implementing dependency-gated issues

**Rule:** When an issue explicitly defers to another (e.g. 'pick up after #N lands'), check *every* prerequisite — the blocking issue AND any data-source or infrastructure PRs it depends on — are merged to `main` before writing a single line of implementation code.

**Why:** Implementing half of a multi-part feature (e.g. surfacing triage cost with no projected-dispatch-cost anchor) can land a worse UX than doing nothing — partial cost surfaces, inconsistent UI rows, or silent scope expansion into undesigned territory.

**How to apply:** On any issue that contains phrases like 'depends on', 'pick up after', 'blocked by', or lists a sibling issue number in its body, run `gh issue view <dep>` and `gh pr list` to confirm merged state before proceeding. If any named dependency is still OPEN or its PR is unmerged, post a pushback with the specific gap and ask the user to choose: hold, expand scope, or accept a flagged skeleton.

**Tells:**
- Issue title or body contains 'depends on #N' or equivalent
- A data-source PR (e.g. one introducing a new field consumed by this issue) exists but is unmerged
- The issue describes UI output that requires a value only another issue's code will produce

<!-- run:run-2026-05-05T17-13-23-624Z issue:#137 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Every value baked into a plan→confirm previewHash must be persisted in the triage cache

**Every numeric/monetary field included in gate text (and therefore in the previewHash) must be explicitly serialized into the disk cache.** Un-persisted fields silently return zero on every cache hit, drifting rendered text between the cold `--plan` pass and the warm `--confirm` pass.
**Why:** `triageBatch` returned `costUsd: 0` on all cache hits because the field was never written to disk. `Triage cost: ~$0.0241` became `Triage cost: ~$0.0000` — a different string, a different hash, a spurious 'Plan diverged' on the very first `--confirm`.
**How to apply:** Whenever a cost, count, or timestamp field is added to gate text, immediately add it to the cache schema too. If caching is infeasible, exclude the field from the hash and store it only in the confirm token.
**Tells:** Divergence only on first `--confirm` after a cold `--plan`; the drifted line shows `$0.00` or `0`; error vanishes after cache clear; line diff points to a cost/count line.

<!-- promote-candidate:content-determined-rendering -->
In two-phase CLI flows (plan/confirm), gate text is hashed to detect drift between phases. Any numeric or monetary field included in that hash which is sourced from a disk cache must be explicitly written to the cache schema. Cache hits that omit a field silently return its zero-value, making rendered text differ between the cold (plan) pass and the warm (confirm) pass, producing a false divergence error on the first confirm after a fresh plan. The pattern is identifiable: divergence only on the first confirm after a cold plan, the drifted line shows a zero/empty value, and clearing the cache resolves it temporarily.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T17-42-15-244Z issue:#142 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## New CLI flags in --plan/--confirm two-phase workflows must be stored in the confirmation token with back-compat defaults

**When a CLI flag affects behavior that spans a `--plan` / `--confirm` two-phase run, persist it in `RunConfirmParams` at plan time and read it back at confirm time.**

**Why:** A flag that only exists at CLI-parse time is silently lost between the two phases. The `--confirm` invocation has no way to recover the operator's original intent without the token, causing the feature to appear wired but never fire on the confirm path.

**How to apply:** Any new field threaded through `OrchestratorInput → RunIssueCoreInput → CodingAgentInput → WorkflowVars` that traces back to a CLI flag and influences confirm-phase behavior must also get a matching optional field in `RunConfirmParams`. Thread the full chain end-to-end in one PR rather than splitting flag addition from wiring.

**Tells:** New `--foo` boolean flag; two-phase CLI with a persisted state/token between phases; existing `RunConfirmParams` shape; behavior 'should fire' but silently does nothing on `--confirm`.

**Back-compat rule:** Old tokens lacking the new field must deserialize cleanly — treat missing as `false` / `undefined`, never throw. Add at least one round-trip test that mints a token *without* the new field and asserts the confirm path still succeeds with the safe default.

<!-- run:run-2026-05-05T22-03-52-041Z issue:#168 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Relax a safety floor via an explicit opt-in flag, never by changing the default

**When an operator requests a lower threshold than an established safety floor, add a per-invocation opt-in flag — do not change the default.** The safe default exists to protect unattended / automated runs; changing it creates silent regression risk for every existing caller.

**Why:** A prior incident (floor raised from 2→3 because 2 was too aggressive for unattended compaction) is the historical contract behind the default. New feature requests that want the lower value are legitimate but must opt in explicitly so that unattended pipelines are unaffected.

**How to apply:** (1) Export the alternative floor as a named constant (e.g. `PAIR_CLUSTER_FLOOR = 2`). (2) Centralize all floor-resolution logic in a single exported helper (e.g. `resolveMinClusterSize({minClusterSize, allowPairClusters})`). (3) The helper owns the precedence table; CLI and tests both import from it. (4) The existing human-in-the-loop gate (`--apply`/`--confirm`) stays untouched — it is orthogonal to threshold relaxation.

**Tells:** issue text says "opt-in for clean cases", "support size=N when default is M", or "lower threshold for a specific scenario".

<!-- promote-candidate:operator-opt-in -->
When a CLI safety floor (e.g. min-cluster-size=3) was established to prevent aggressive behavior in unattended runs, requests to lower it are implemented as an explicit per-invocation opt-in flag rather than a default change. The floor values are exported as named constants (PAIR_CLUSTER_FLOOR, DEFAULT_MIN_CLUSTER_SIZE), and a single exported resolver function owns the precedence table. This keeps the safe default intact for all automated callers while giving operators a documented escape hatch.
<!-- /promote-candidate -->

<!-- run:run-2026-05-04T14-37-10-004Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Thread-through parameter changes exhaust turn budget when edited site-by-site

**When plumbing a new option end-to-end (CLI flag → interface → parse → propagate → runtime use), enumerate every change site up front and batch all edits into the fewest possible tool calls before touching any file.**

**Why:** Each granular Edit call costs one turn. A 5-site thread-through (option declaration, interface field, profile merge, run-params spread, logger log) plus build + test + commit + push + PR creation requires ~15 turns at minimum. Executing those same changes as N small targeted edits can consume 35+ turns, leaving no budget for the finalization steps — agent crashes at "all tests pass, committing" with zero turns left.

**How to apply:** On any issue whose title implies adding a flag, limit, ceiling, or config knob: (1) read all relevant files first, (2) write a mental edit plan listing every location, (3) apply each file's changes in a single large Edit or Write, never one field at a time. Reserve at least 8 turns for build → test → commit → push → PR before making the first code change.

**Tells:** Issue title contains "ceiling", "limit", "option", "per-run", "config"; implementation touches a CLI parser, a typed options interface, and one or more downstream call sites — the combination signals a multi-site thread-through.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#84 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Multi-file flag propagation exhausts turn budget when edits are piecemeal

**When threading a new CLI flag through 5+ files, prefer full-file `Write` or large batched `Edit` calls over many small sequential edits.**

**Why:** Each `Edit` is a turn; a flag that propagates through CLI → interface → orchestrator → state → preview can require 20–30 edits before the first build check, burning most of the 50-turn budget and leaving no room for compilation errors or iteration.

**How to apply:** Before starting, enumerate every file to touch and estimate edits per file. If total estimated edits > 20, switch to full-file `Write` for the most-edited files. Alternatively, widen `old_string` to capture and replace an entire function signature or interface block in one call instead of editing one field at a time.

**Tells:** New option added to a shared interface that also appears in CLI opts, orchestrator params, dispatcher args, state serialization, and a preview formatter — classic fan-out propagation where each layer needs its own edit.

<!-- run:run-2026-05-03T05-54-13-869Z issue:#62 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Commit-push-envelope must be consecutive turns; pre-commit verification burns kill the envelope

**After `git push` succeeds, emit the decision envelope in the very next turn — no intervening reads, greps, or build re-checks.**

**Why:** Agents that front-load exhaustive verification (build → typecheck → test → grep wiring checks) before the final commit+push consume most of the 50-turn budget. The push lands on turn 49 and there is no turn left to emit the envelope. The SDK sees an unfinished run and records a crash, discarding all the work even though the branch was pushed.

**How to apply:** Treat the final sequence as atomic and inviolable: `git add/commit` → `git push` → emit envelope. If optional validation (typecheck, test, grep cross-checks) hasn't been done yet, skip it rather than defer the envelope. The pushed branch is recoverable; a missing envelope is not.

**Tells:** Five or more of build/typecheck/test/grep calls appearing in the last 15 turns before the first commit attempt signals the budget is almost gone — stop verifying and push immediately.

**Corollary:** If the issue fix requires iterative build-fix cycles, do them in the first half of the turn budget. Reserve the second half for commit + push + envelope only.

<!-- run:run-2026-05-04T14-08-59-410Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Batch multi-site edits into one Write per file to avoid turn-ceiling exhaustion on feature work

**When implementing a feature that touches many locations in a file, consolidate all changes into a single `Write` (full-file replacement) or the fewest possible `Edit` calls — never one `Edit` per change site.**

**Why:** The 50-turn SDK ceiling is consumed by granular per-hunk edits before implementation, tests, and CI verification can complete, causing the agent to crash without emitting an envelope. The pattern is self-defeating: the more carefully the agent edits, the less likely it finishes.

**How to apply:** Before touching a file, enumerate every change site; write them all in one pass. If turn count passes 30 with build/test not yet green, switch immediately to `Write` for each remaining file rather than continuing surgical edits.

**Tells:**
- 5+ sequential `Edit` calls to the same file in the visible tool log
- `npm run build` / `npm test` not reached until the final 2 turns
- Agent still adding interface fields or CLI options after turn 40

**Corollary:** For features requiring new CLI flags + new interfaces + new logic + new tests, treat each file as one atomic unit of work — read the full file, plan all changes mentally, write it once.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#86 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Create the PR immediately after push — post-push verification burns turns needed for the deliverable

**After `git push` succeeds, call `gh pr create` as the very next action — before any `git log`, `git show --stat`, or `gh pr list` checks.**

**Why:** Post-push verification steps (confirming commit hashes, listing PRs, inspecting file stats) consume turns without advancing toward the actual deliverable. When a turn ceiling is close, these confirmation calls prevent PR creation from completing — leaving a fully-committed, fully-pushed branch with no open PR, which recovery passes can't fix in 4 turns if they also burn turns on re-verification.

**How to apply:** Write the PR body to a temp file early in the session (right after tests pass). After push, immediately call `gh pr create --body-file`. Reserve `git log` / `gh pr list` / `git show` only as diagnostics *if* the create step itself fails or returns an error.

**Tells:** Seeing `git log --oneline`, `git show --stat`, and `gh pr list` all appearing *after* `git push` but *before* `gh pr create` is the signature of turn-exhaustion-before-delivery risk.

<!-- run:run-2026-05-04T14-08-59-410Z issue:#62 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Partition dispatch list against open PRs before creating worktrees to prevent branch-collision failures

**Always query open PRs before dispatching issues that create named branches or worktrees; remove issues already covered by an open PR from the dispatch list rather than attempting to re-mint the same branch.**

**Why:** The stale-sweep correctly preserves `vp-dev/<agentId>/issue-<N>` branches when live PRs depend on them, but the dispatcher then calls `git worktree add -b <branch>` for the same `(agentId, issueId)` on the next run. The branch already exists, so the command fails silently under a generic uncaught-error path — the issue is dropped with no visible warning and no retry. The collision rate compounds across runs.

**How to apply:** At the start of any `run` or `resume` command, make a single `gh pr list --state open` call (or equivalent), parse the branch names to extract covered issue IDs, and call a pure `partitionOpenPrIssues` helper that splits the candidate list into `(toDispatch, alreadyCovered)`. Surface `alreadyCovered` in the user-facing y/N gate alongside `triageSkipped` so operators see why issues are being held back.

**Tells:** dispatch command creates branches with deterministic names derived from `(agentId, issueId)` · stale-sweep is configured to preserve branches with open PRs · errors appear as `error.agent.uncaught` on `git worktree add` rather than a named dispatch failure · issue loss rate grows with the number of open PRs.

**How to apply (scope):** Add the preflight partition to every entry-point that calls `git worktree add -b`; a single RPC call at run start is cheaper than a per-issue retry loop and avoids the race entirely. Prefer the smallest fix (filter before dispatch) over branch-salting or orchestrator-level overrides.
