# Tailored CLAUDE.md for issue #186 (szhygulin/vaultpilot-dev-framework)

Built by `research/curve-redo-bundle/super-agent-tailored/build-tailored-agents.cjs`.
Source: `research/curve-redo-bundle/super-agent/agent-super.CLAUDE.md` (122 sections).
Selector: claude-opus-4-7[1m]; kept 10/122 sections.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#38 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Inject pre-written feature-plans into the agent seed as authoritative design guidance, before the workflow block

**Glob `feature-plans/issue-<N>-*.md` in the worktree and, when a match exists, append its content as a named section between the agent's CLAUDE.md and the workflow block, marked 'authoritative design guidance'.**
**Why:** Without an explicit upfront plan, coding agents reinvent file layouts and architecture from scratch on every run, causing design drift across reruns and wasted tokens re-litigating structure already decided by a human architect.
**How to apply:** Any change to `buildAgentSystemPrompt()` or equivalent prompt-assembly entry points should preserve and sit below this plan-injection step; once a plan file is committed to `feature-plans/`, it takes effect on the next run with zero other infrastructure.
**Tells:** An issue has a matching `feature-plans/` file already committed; the prompt assembly doesn't reference it yet; or the agent's proposed file layout diverges from the pre-written plan.
**Ordering discipline:** Ship the plan-consumption path (reading existing files) before the plan-production path (live Opus planner, complexity gate, orchestrator state). Hand-written plans already exist and pay off immediately; the planner that generates them is a separate, deferrable phase.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#101 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Two-tier (global / per-target) store extension: XDG path, tier discriminant, ENOENT-empty, load order

**When elevating any per-target store to cross-repo scope, introduce a `Tier = "target" | "global"` discriminant; resolve the global path via `$XDG_CONFIG_HOME/<app>/` with `~/.<app>/` as fallback; thread the tier param through every path-resolver, reader, and writer.** In prompt construction load global-tier entries first so per-target entries supplement rather than replace them. Treat ENOENT on either tier as an empty result, never an error.

**Why:** The shared-lessons global tier validated this pattern end-to-end. XDG compliance keeps the global store at a user-controllable location independent of any target-repo clone. ENOENT-empty semantics let the global tier be absent on fresh machines without breaking anything.

**How to apply:** Any time a store currently scoped to `agents/.shared/` needs to survive repo moves or span multiple target repos — shared lessons, agent memory, rubrics, skill maps.

**Tells:** Feature request mentions "portable", "cross-repo", or "machine-wide"; existing data lives under `agents/.shared/`; a new `--global` CLI flag is requested.

**Test checklist (9 cases minimum):** XDG env-var honored, `~/.<app>/` fallback honored, tier dispatch (write lands in correct dir), validation refusal, ENOENT → empty, tier isolation (no cross-bleed).

<!-- promote-candidate:cross-target-repo -->
Vaultpilot implements a two-tier store ("target" and "global") for shared domain knowledge. The global tier lives at `$XDG_CONFIG_HOME/vaultpilot/shared-lessons/` with `~/.vaultpilot/shared-lessons/` as the fallback. The per-target tier stays at `agents/.shared/lessons/` inside the target repo. At agent-prompt-build time both tiers are read per-domain: global entries load first, per-target entries append afterward. ENOENT on either tier resolves to an empty list; neither tier's absence is treated as an error. Promotion to either tier remains human-gated; the `--global` flag selects which tier `vp-dev lessons review` writes to.
<!-- /promote-candidate -->

<!-- run:run-2026-05-04T14-37-10-004Z issue:#33 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Consolidate commit-phase steps to avoid turn exhaustion before final git commit

**After tests pass, commit within 2 turns: combine `git add` and `git commit -m "..."` in one Bash call — no interim diff reviews, no temp-file message drafts, no redundant `git status` or `git fetch` calls.**
**Why:** Agents burn turns in the cleanup phase (reviewing diffs of already-reviewed files, writing commit messages to `/tmp/`, re-running builds that just passed) and hit the 50-turn ceiling before issuing `git commit`, leaving complete, tested work uncommitted.
**How to apply:** The moment `npm test` (or equivalent) is green and you know which files changed, issue `git add -A && git commit -m "<message>"` immediately — one Bash call. Don't split staging, committing, and verification across separate turns.
**Tells:** Last tool calls show ≥3 consecutive git diff / git status / git fetch / Write-to-/tmp/ calls with no `git commit` issued — the agent is in stall-loop review mode after implementation is already done.
**Guard rule:** Never write a commit message to a temp file; write it inline. Never re-run a build that just passed clean. If you catch yourself doing either, skip straight to the commit call.

<!-- run:run-2026-05-09T02-20-51-182Z issue:#268 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## When splitting a dispatcher prompt for caching, any tick-varying value must live in the volatile suffix

**When splitting a dispatcher prompt for caching, any tick-varying value must live in the volatile suffix — not the stable prefix — even if it feels structural.**
**Why:** Cap directives, current pending-issue lists, prior-attempt errors, and prefer-agent overrides all differ between ticks or between a first attempt and its validation retry; leaving them in the stable prefix silently busts the cache on every such change.
**How to apply:** Stable prefix = preamble + routing rules rewritten cap-agnostic + per-agent CLAUDE.md prose deduped against seed. Volatile suffix = pending issues + cap directive + prefer-agent override + prior-attempt errors + JSON shape directive.
**SDK wiring:** `systemPrompt: [prefix, SYSTEM_PROMPT_DYNAMIC_BOUNDARY]`, suffix passed as `prompt`; cache telemetry lives on `result.usage.cache_creation_input_tokens` / `cache_read_input_tokens`.
**Test discipline:** add byte-identity assertions on the prefix across (a) the validation-retry round-trip and (b) cap-shrinkage — those are the two most common invalidation paths.
**Tells:** routing rules that reference a specific agent cap, error strings in the system prompt, or issue lists embedded in the preamble — all signal prefix contamination.
<!-- promote-candidate:prompt-caching -->
The Agent SDK exposes prompt caching via `systemPrompt: string[]` with `SYSTEM_PROMPT_DYNAMIC_BOUNDARY` as a sentinel element; the suffix is passed as `prompt`. Cache hit/miss telemetry is on `result.usage`: `cache_creation_input_tokens` and `cache_read_input_tokens`. Cap directives and per-tick state (pending issues, prior-attempt errors, prefer-agent overrides) must stay in the volatile suffix; only truly tick-invariant content (preamble, cap-agnostic routing rules, static CLAUDE.md prose) belongs in the stable prefix. The most common invalidation paths are the validation-retry round-trip and cap-shrinkage between ticks.
<!-- /promote-candidate -->

<!-- run:run-2026-05-04T14-37-10-004Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Thread-through parameter changes exhaust turn budget when edited site-by-site

**When plumbing a new option end-to-end (CLI flag → interface → parse → propagate → runtime use), enumerate every change site up front and batch all edits into the fewest possible tool calls before touching any file.**

**Why:** Each granular Edit call costs one turn. A 5-site thread-through (option declaration, interface field, profile merge, run-params spread, logger log) plus build + test + commit + push + PR creation requires ~15 turns at minimum. Executing those same changes as N small targeted edits can consume 35+ turns, leaving no budget for the finalization steps — agent crashes at "all tests pass, committing" with zero turns left.

**How to apply:** On any issue whose title implies adding a flag, limit, ceiling, or config knob: (1) read all relevant files first, (2) write a mental edit plan listing every location, (3) apply each file's changes in a single large Edit or Write, never one field at a time. Reserve at least 8 turns for build → test → commit → push → PR before making the first code change.

**Tells:** Issue title contains "ceiling", "limit", "option", "per-run", "config"; implementation touches a CLI parser, a typed options interface, and one or more downstream call sites — the combination signals a multi-site thread-through.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#84 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Multi-file flag propagation exhausts turn budget when edits are piecemeal

**When threading a new CLI flag through 5+ files, prefer full-file `Write` or large batched `Edit` calls over many small sequential edits.**

**Why:** Each `Edit` is a turn; a flag that propagates through CLI → interface → orchestrator → state → preview can require 20–30 edits before the first build check, burning most of the 50-turn budget and leaving no room for compilation errors or iteration.

**How to apply:** Before starting, enumerate every file to touch and estimate edits per file. If total estimated edits > 20, switch to full-file `Write` for the most-edited files. Alternatively, widen `old_string` to capture and replace an entire function signature or interface block in one call instead of editing one field at a time.

**Tells:** New option added to a shared interface that also appears in CLI opts, orchestrator params, dispatcher args, state serialization, and a preview formatter — classic fan-out propagation where each layer needs its own edit.

<!-- run:run-2026-05-03T05-54-13-869Z issue:#62 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Commit-push-envelope must be consecutive turns; pre-commit verification burns kill the envelope

**After `git push` succeeds, emit the decision envelope in the very next turn — no intervening reads, greps, or build re-checks.**

**Why:** Agents that front-load exhaustive verification (build → typecheck → test → grep wiring checks) before the final commit+push consume most of the 50-turn budget. The push lands on turn 49 and there is no turn left to emit the envelope. The SDK sees an unfinished run and records a crash, discarding all the work even though the branch was pushed.

**How to apply:** Treat the final sequence as atomic and inviolable: `git add/commit` → `git push` → emit envelope. If optional validation (typecheck, test, grep cross-checks) hasn't been done yet, skip it rather than defer the envelope. The pushed branch is recoverable; a missing envelope is not.

**Tells:** Five or more of build/typecheck/test/grep calls appearing in the last 15 turns before the first commit attempt signals the budget is almost gone — stop verifying and push immediately.

**Corollary:** If the issue fix requires iterative build-fix cycles, do them in the first half of the turn budget. Reserve the second half for commit + push + envelope only.

<!-- run:run-2026-05-04T14-08-59-410Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Batch multi-site edits into one Write per file to avoid turn-ceiling exhaustion on feature work

**When implementing a feature that touches many locations in a file, consolidate all changes into a single `Write` (full-file replacement) or the fewest possible `Edit` calls — never one `Edit` per change site.**

**Why:** The 50-turn SDK ceiling is consumed by granular per-hunk edits before implementation, tests, and CI verification can complete, causing the agent to crash without emitting an envelope. The pattern is self-defeating: the more carefully the agent edits, the less likely it finishes.

**How to apply:** Before touching a file, enumerate every change site; write them all in one pass. If turn count passes 30 with build/test not yet green, switch immediately to `Write` for each remaining file rather than continuing surgical edits.

**Tells:**
- 5+ sequential `Edit` calls to the same file in the visible tool log
- `npm run build` / `npm test` not reached until the final 2 turns
- Agent still adding interface fields or CLI options after turn 40

**Corollary:** For features requiring new CLI flags + new interfaces + new logic + new tests, treat each file as one atomic unit of work — read the full file, plan all changes mentally, write it once.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#86 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Create the PR immediately after push — post-push verification burns turns needed for the deliverable

**After `git push` succeeds, call `gh pr create` as the very next action — before any `git log`, `git show --stat`, or `gh pr list` checks.**

**Why:** Post-push verification steps (confirming commit hashes, listing PRs, inspecting file stats) consume turns without advancing toward the actual deliverable. When a turn ceiling is close, these confirmation calls prevent PR creation from completing — leaving a fully-committed, fully-pushed branch with no open PR, which recovery passes can't fix in 4 turns if they also burn turns on re-verification.

**How to apply:** Write the PR body to a temp file early in the session (right after tests pass). After push, immediately call `gh pr create --body-file`. Reserve `git log` / `gh pr list` / `git show` only as diagnostics *if* the create step itself fails or returns an error.

**Tells:** Seeing `git log --oneline`, `git show --stat`, and `gh pr list` all appearing *after* `git push` but *before* `gh pr create` is the signature of turn-exhaustion-before-delivery risk.

<!-- run:run-2026-05-02T06-32-08-433Z issue:#32 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Reuse existing sentinel formats when adding parallel output paths — extend with a new variant value

**When a plan calls for a separate sentinel or marker format for a new parallel path, prefer adding a variant value to the existing format instead.**
**Why:** A new sentinel shape forces every downstream consumer — pruner, filter, parser — to be updated simultaneously; missed updates cause silent data loss or double-processing. Extending the existing format (e.g. `outcome:failure-lesson` alongside `outcome:lesson`) leaves all current consumers compatible with zero changes and shrinks the diff surface.
**How to apply:** Before introducing a new sentinel shape, check whether the existing marker has a string/enum field that can carry a new value. Accept a wholly new format only when the semantics are genuinely incompatible with the existing shape.
**Tells:** Plan says 'introduce a separate sentinel format'; existing sentinel has a fixed `outcome:` or `type:` discriminator field; at least one downstream pruner/filter already handles the existing format.
**Corollary:** Apply the same principle to error classifiers — add an `isInfraFlake` (or equivalent noise-gate) guard on any new error-handling path so that transport / 5xx / filesystem failures that carry no learning value are silently dropped rather than producing junk output.
