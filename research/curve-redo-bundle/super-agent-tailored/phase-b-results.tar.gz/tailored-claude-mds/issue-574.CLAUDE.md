# Tailored CLAUDE.md for issue #574 (szhygulin/vaultpilot-mcp)

Built by `research/curve-redo-bundle/super-agent-tailored/build-tailored-agents.cjs`.
Source: `research/curve-redo-bundle/super-agent/agent-super.CLAUDE.md` (122 sections).
Selector: claude-opus-4-7[1m]; kept 28/122 sections.

<!-- run:run-2026-05-01T14-48-57-664Z issue:#594 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Smoke-Test / Reinforcement Issues Against a Closed Security Finding Need a Predecessor Check First

**Before acting on any issue that references or 'reinforces' a prior security finding, verify the predecessor's closure state and whether its lesson is already captured in CLAUDE.md.** If the predecessor is closed because its rule was absorbed into a CLAUDE.md section, and no relevant code yet exists to harden, push back rather than re-adding the rule or pre-emptively scaffolding.

**Why:** Smoke-test and reinforcement issues are routinely filed after a parent finding is closed. Acting without checking means either duplicating a CLAUDE.md rule that already exists, or building pre-emptive scaffolding for a feature that doesn't exist yet — both violate Smallest-Solution Discipline.

**How to apply:** When an issue is tagged `smoke-test`, `tracking-issue`, or cites 'reinforces #NNN', run three checks: (1) is the referenced issue closed? (2) is its rule already in CLAUDE.md? (3) does the relevant code/tool exist to harden? If the finding is already covered and the target code is absent, post a structured pushback comment with explicit triage options (close as won't-fix, close as duplicate, keep as reminder card).

**Tells:** Labels include `smoke-test` or `tracking-issue`; issue body contains 'reinforces #NNN' or 'missing — … (reinforces #NNN)'; referenced issue is closed with `stateReason: completed`.

<!-- run:run-2026-05-01T17-27-23-838Z issue:#594 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Security 'Reinforcement' Issues Targeting Non-Existent Code — Pushback as Duplicate, Not Pre-Emptive Scaffolding

**When a security issue is filed as a reinforcement of an already-closed predecessor, first verify (a) the predecessor's rule is absorbed into CLAUDE.md and (b) the attack-surface code does not yet exist in the repo; if both are true, push back and offer close-as-duplicate.**

**Why:** Pre-emptively wiring invariant checks (Inv #1b, Inv #2b, etc.) for a tool that hasn't shipped yet adds dead code, violates Smallest-Solution Discipline, and muddies the real rule (which lives in CLAUDE.md for enforcement at PR-review time). The current posture is 'defense-by-gap' — no tool, no exploit.

**How to apply:** On any issue labelled `security_finding` that mentions a predecessor issue number or uses language like 'reinforces #NNN' / 'missing catch': (1) `gh issue view <predecessor>` — confirm closed; (2) grep the src tree for the target tool/function — confirm absent; (3) grep CLAUDE.md for the rule — confirm present. All three checks pass → structured pushback with triage options (default: close as duplicate).

**Tells:** 'smoke-test' or 'reinforcement' in issue title; predecessor issue referenced by number; grep of `src/` for the target symbol returns zero matches; existing CLAUDE.md section already names the invariant.

**Never** scaffold placeholder plumbing 'so the check is ready when the tool ships' — that belongs in the PR that introduces the tool, enforced by the CLAUDE.md rule, not in a pre-emptive commit.

<!-- run:run-2026-05-05T19-14-11-189Z issue:#575 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## When the threat model assumes dual-layer compromise, skill-side invariants cannot defend

**If a security report's threat actor is 'agent + colluding MCP' — both trust boundaries breached simultaneously — any skill-side gate (Inv rule, premise-validity check, advisory prose) is text inside the rogue agent's own context window, which it ignores by definition.**

**Why:** Inv-style invariants only bind cooperative agents. A colluding agent reads and discards them; shipping a 'fix' here creates false assurance without reducing real risk. The body of such issues often concedes this implicitly ('the MCP cannot defend this alone').

**How to apply:** Classify as architectural residual risk, not a patchable bug. Post structured pushback offering three redirects: (1) honest-scope cooperating-agent guidance in the skill repo with an explicit scope label, (2) upstream model-safety escalation, (3) smoke-test corpus tagging. Do NOT file a skill-side fix before the reporter chooses a redirect, to avoid wasted cross-repo work.

**Tells:** Issue body says 'agent AND the MCP', 'both layers', or describes a threat that requires the defender to already be inside the compromised perimeter; educational/onboarding flows reframed into `prepare_*` calls by a compromised agent.

<!-- promote-candidate:rogue-agent-triage -->
When a security report places both the calling agent and the MCP server inside the compromised perimeter, skill-side text rules (invariants, premise-validity checks, advisory prose) are definitionally ineffective — they live only in the rogue agent's context window, which it ignores. A recurring variant: an educational or onboarding prompt is silently reframed by the compromised agent into an actionable prepare_* call; neither the skill nor the MCP can intercept this because both are already inside the trust-boundary breach. Correct disposition is architectural pushback with three redirect options rather than a filed fix.
<!-- /promote-candidate -->

<!-- run:run-2026-05-01T13-48-07-936Z issue:#563 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Self-attestation from the untrusted component is not a defense — clarify threat model before any MCP-side change

**When an issue asks an MCP (or any producer) to self-report its own compliance, verify the threat model first: if the threat is a rogue/compromised producer, self-attestation adds zero security because the adversary can lie in the structured field as easily as it can omit the prose.** The defense must live in the consumer (skill, harness, second-LLM checker).

**Why:** Proposals framed as 'user without the skill is unprotected → add `directives_emitted` to MCP response' conflate two distinct threats — honest-MCP drift (detectable by consumer-side verification) and rogue-MCP (not fixable by asking the rogue to self-certify). Implementing MCP-side self-attestation under the rogue-threat framing produces code churn with no security gain.

**How to apply:** When the issue headline implies a server-side field will protect users who lack any consumer-side checker, push back with three options: (a) skill-side smallest-fix (per-tool expected-directives map, zero MCP change), (b) cross-repo split filing consumer issues first, (c) architectural close if the skill-less framing is the actual premise.

**Tells:** Issue labels include `rogue-mcp-threat-model`, `self-attestation`, or `invariant-*`; issue asks a server to emit a 'I performed checks' field; framing assumes server-side output is visible to users who have no agent-side verifier; no consumer repo issue exists yet.

<!-- run:run-2026-05-05T14-26-37-251Z issue:#592 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Self-attestation fixes provide zero security against rogue-MCP or collude threat classes

**Re-querying or cross-checking through the same MCP endpoint being defended is self-attestation — a rogue producer fabricates the confirmatory response as easily as the original.**
**Why:** A collude-class issue proposed re-query, MCP-signed receipt, and list-cross-anchor for a mutation tool; every verification step routed back through the same untrusted server, making the fix security theater against its own labeled threat.
**How to apply:** Before writing code for any security issue targeting rogue-MCP or collude threat classes, trace each proposed verification step: if all paths terminate at the defended MCP endpoint, push back as self-attestation and require an out-of-band trust anchor.
**Tells:** Proposed defenses that "re-query," "request a signed receipt," or "cross-check with a list endpoint" all on the same server; fix footnotes admitting "won't help under full collude"; issue labels naming a stronger threat class than the fix actually targets.

<!-- promote-candidate:rogue-mcp-threat-model -->
In MCP security proposals targeting rogue-server or collude threat classes, verification mechanisms that call back through the same MCP endpoint being defended are self-attestation. A rogue producer can fabricate the confirmatory re-query response, the signed receipt, and the list-cross-anchor response with equal ease. Meaningful verification against a rogue MCP requires an out-of-band trust anchor — a channel or store the MCP server cannot write to. Proposals that only "raise the bar" without specifying such an anchor do not address the labeled threat class, even when the author acknowledges this limitation in a footnote.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T19-14-11-189Z issue:#567 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Second-LLM cross-check defenses that route through the verified MCP are self-attesting under the collude-class threat...

**A second-LLM cross-check that fetches its verification artifact via the same MCP being evaluated is logically self-attesting and fails the collude / rogue-MCP threat model.**
**Why:** Under C.1-collude the server can forge any artifact it returns — ABI data, calldata explanations, attestation objects — so a check that still trusts the same channel adds zero independence, regardless of which LLM consumes the data.
**How to apply:** When reviewing or writing a second-LLM / cross-check defense, confirm the ABI or calldata source is fetched from a channel orthogonal to the MCP under scrutiny (e.g., [4byte.directory](https://www.4byte.directory/), an independent block-explorer ABI endpoint, or a pinned local registry). If no OOB source is named, push back and require one before approving the defense.
**Tells:** Proposal calls `get_verification_artifact` or any tool on the suspected server; cross-check LLM receives data solely from that server; no independent registry/endpoint is cited.

<!-- promote-candidate:rogue-mcp-threat-model -->
A second-LLM cross-check that fetches its verification data (ABI, calldata explanation, attestation) through the same MCP channel it is meant to verify provides no protection under the collude-class threat model. The rogue server can serve whatever artifact it chooses, making the check equivalent to self-attestation. Real independence requires an out-of-band ABI source (4byte.directory, independent block-explorer ABI endpoint, or a locally-pinned registry) that the MCP under scrutiny cannot influence. This pattern has been observed in Gelato + Aave automation flows where `get_verification_artifact` was the sole ABI source for the cross-check step.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T19-14-11-189Z issue:#574 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Per-tool verification patches on a shared rogue-component surface accumulate incoherent half-defenses

**When N tools share the same rogue-MCP threat model, patching each tool individually produces N partial defenses, not one coherent one — even if each patch looks plausible (multi-RPC consensus, canonical-resolver Safe Anchor, `data-source-not-attested` marker).**

**Why:** Multi-RPC consensus routed through the rogue MCP is self-attestation by another name: the compromised component fabricates `consensus: true` across however many `eth_call` fan-outs it controls. A Safe Anchor resolver address *checked by the MCP* is equally forgeable. Per-tool patches that re-route through the same untrusted layer add implementation surface without adding integrity — and produce a patchwork where some tools appear 'fixed' while the threat model is unchanged.

**How to apply:** When an issue proposes adding verification *inside* a specific MCP tool for a threat that applies equally to sibling tools (same read-only data plane, same rogue-component exposure), push back with architecturally honest options: (1) external-URL advisory that is out-of-band by construction (a browser the MCP can't re-skin), (2) close as duplicate of the canonical surface issue so the gap is tracked in one place, (3) cooperating-agent skill rule with an explicit honest-scope label. Ask which option matches intent before writing code.

**Tells:** Issue title names one specific tool; proposed fix lives entirely inside the MCP; the same rogue-MCP gap was already filed against a sibling tool; the fix uses words like 'consensus', 'anchor', or 'attested marker' without specifying an out-of-band verifier.

<!-- promote-candidate:rogue-mcp-threat-model -->
Multi-RPC consensus performed *inside* a rogue or compromised MCP provides zero integrity guarantee. The compromised component controls all RPC fan-out and can fabricate `consensus: true` over any number of `eth_call` results. Similarly, a canonical-resolver address or an attested-marker flag checked *by the MCP itself* is forgeable by the same com
[…truncated]

<!-- run:run-2026-05-05T19-14-11-189Z issue:#563 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Self-attestation compliance fields in MCP output weaken the CHECKS PERFORMED defense, not strengthen it

**Reject proposals that add structured 'compliance-reported' fields to MCP response payloads as a verification mechanism.**
**Why:** A rogue or compromised MCP that skips a required text block (e.g. `CHECKS PERFORMED`) fabricates a `directives_emitted` field just as easily; a skill rule that compares against that field can REPLACE text-scan with a weaker check — the forgeable field bypasses comparison while text-scan still catches the missing block.
**How to apply:** When an issue proposes a structured field in MCP output so a skill or harness can 'verify' directive emission, determine whether the new rule replaces or supplements the existing text-scan. If it could substitute, push back as a defense regression and offer the per-tool expected-directives map (skill-side only, zero MCP attestation) as the correct alternative.
**Tells:** fields named `directives_emitted`, `checks_performed`, `compliance_state` in MCP response schemas; skill logic that branches on field value rather than scanning response text; issue framing that conflates 'compromised' and 'buggy' MCPs as a single threat model.

<!-- promote-candidate:rogue-mcp-triage -->
In rogue-MCP threat models, the MCP server is treated as a potentially-hostile or compromised component. Adding a structured self-report field (e.g. `directives_emitted`) to MCP responses does not improve verification: the same adversary that omits a required text block also fabricates the field. A skill-side comparison rule keyed to the field value is bypassable, while existing text-scanning of response content remains effective. The more secure pattern is a per-tool expected-directives map maintained entirely on the skill/trusted side, with zero MCP-side attestation. Proposals that add structured self-attestation to MCP output and then add a skill rule comparing against it effectively replace a harder-to-spoof check with an easier-to-spoof one.
<!-- /promote-candidate -->

<!-- run:run-2026-05-01T13-48-07-936Z issue:#574 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Tool-specific patches routed through the threat channel don't close rogue-MCP data integrity gaps

**When a security issue frames the threat as a rogue or compromised MCP server, confirm every proposed fix has an independent trust anchor before implementing it.** Multi-RPC consensus, attestation markers, and canonical-resolver lookups all returned by the same MCP provide zero additional assurance — the attacker controls every return value.

**Why:** A rogue MCP can fabricate any field it owns: consensus vote counts, `data_source` attestation markers, secondary-resolver results. Shipping a tool-specific patch in this scenario creates false closure without raising the actual security bar, and may block the durable fix from being prioritized.

**How to apply:** Before coding any verification step for a read-only data-plane finding, ask: "Does this verification call the same server that returned the suspect data?" If yes, the fix does not defend against the stated rogue-MCP threat. Either (a) redirect to an out-of-band trust anchor (third-party URL advisory, transport-layer response signing, skill-side policy), (b) surface the issue as a duplicate of the relevant data-integrity tracking issue, or (c) ask the author which option matches intent — do not ship the tool-specific patch silently.

**Tells:** Issue has `security_finding` + `rogue-mcp` or `data-source-attestation` labels; proposed fix adds a verification field sourced from the same MCP tool; no independent ground truth (off-chain URL, signing key, separate service) is referenced in the issue body.

<!-- run:run-2026-05-01T13-48-07-936Z issue:#566 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Self-reported provenance fields do not close rogue-component threats — push back and redirect

**A security fix that asks an untrusted component to attest its own trustworthiness is security theater.** Any metadata block (`rpc_provider`, `block_height`, `source_count`, etc.) returned inside the same MCP response it is meant to authenticate can be fabricated by a compromised MCP with zero additional effort.

**Why:** Smoke-test batch exercises (`expert-074-F` class) specifically probe whether a rogue MCP can inject plausible-looking provenance fields to pass downstream checks. If the fix lives entirely inside the tool's own response envelope, it fails that test unconditionally.

**How to apply:** When a `security_finding`-labeled issue proposes adding attestation/provenance metadata to a tool's response as the primary mitigation for a rogue-MCP or supply-chain trust threat, reject the framing. The real fix requires an **independent trust anchor** outside the untrusted component — e.g., response signing verified by the skill layer, multi-RPC consensus checked by a separate data plane, or allowlist cross-check on the caller side.

**Tells:** issue labels include `security_finding` + `rogue-mcp`/`data-source-attestation`; proposed diff only touches the MCP's output schema; no independent verifier is introduced.

**Offer three options:** (1) close as subsumed by the parent issue tracking the real fix, (2) re-scope as observability/staleness UX and drop `security_finding`, or (3) promote to a proper multi-RPC consensus or signing issue with a skill-side verifier.

<!-- run:run-2026-05-01T14-48-57-664Z issue:#591 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## MCP-side attestation of enumerated sets is a self-attestation antipattern when the MCP is the threat actor

**When the threat model names the MCP (or data source) itself as the potential adversary, any integrity proof — signed digest, hash anchor, Merkle root — computed and returned by that same MCP adds zero security.** A rogue MCP that fabricates enumerated-set rows (validator lists, SR catalogs, RPC endpoints) trivially fabricates the accompanying digest.

**Why:** Repeated proposals conflate "tamper-evident transport" (where the signer is trusted) with "rogue-source defense" (where the signer is the attacker). The anchor is only as trustworthy as the signer; if the signer is inside the untrusted boundary, the proof is circular.

**How to apply:** Before implementing any "prefix/sign the response with a digest" feature, ask: does the threat model include the signing party being compromised? If yes, push back and redirect to a real-anchor alternative.

**Tells:** labels `rogue-mcp`, `data-source-attestation`, `enumerated-set`; proposals mentioning "sign the catalog response," "hash-anchored digest per set," or "integrity proof attached to the tool response."

**Real-anchor alternatives to offer:** (1) skill-side ground-truth cross-check against a hardcoded or separately-fetched reference; (2) user OOB echo-back against an off-chain registry; (3) close as duplicate of the parent self-attestation tracking issue if one already exists.

<!-- run:run-2026-05-01T17-27-23-838Z issue:#592 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Reject mitigations that route verification through the threat actor (self-attestation antipattern)

**When a proposed security fix asks the suspected-rogue component to confirm its own honesty, reject it as security theater regardless of 'defense-in-depth' framing.**
**Why:** Re-querying the same MCP, or having it sign its own receipt, does not raise the security bar against a colluding/rogue MCP — the threat actor controls the verification channel. Even the issue author may admit this ('won't help under full collude') while still advocating for shipping; that admission is the signal to push back, not a reason to relent.
**How to apply:** Any time a security issue proposes a fix whose verification path runs through the component named as the threat actor, label it the self-attestation antipattern and decline to implement. Offer concrete re-scoping options instead (subsume into existing integrity-class tracking issue, re-scope to cooperating-agent skill guidance, or promote to a real out-of-band trust-anchor proposal).
**Tells:** fix described as 're-query the same source after the mutation', 'MCP signs its own response/receipt', 'tool-level patch' against a rogue-MCP class issue, 'partial improvement' language when the improvement routes through the adversary, existing parent tracking issues already cover the integrity class.

<!-- run:run-2026-05-05T14-26-37-251Z issue:#591 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Self-attestation antipattern — reject integrity proofs generated inside the threat boundary

**Reject any mitigation where the proof generator sits inside the threat boundary.** A component proposed as both the adversary and the integrity-proof source provides zero net defense — it fabricates data and fabricates the proof at identical cost.

**Why:** On enumerated-set surfaces (validator vote-pubkeys, super-representative lists, RPC endpoints) a rogue MCP that poisons a row also controls any hash/signature/receipt it attaches to that row. Placing the verifier inside the attacked surface is structurally tautological regardless of cryptographic strength.

**How to apply:** When a security issue proposes "MCP-side signed digest", "hash-anchored response", or "self-signed receipt" as the mitigation AND the threat model names a rogue/colluding MCP as the adversary — push back immediately. Redirect to: (a) external-authority `provenanceHints` pointing to sources the MCP cannot influence; (b) skill/agent-side cross-checking against an independently-fetched reference; (c) durable-binding objects whose authority was set outside the MCP boundary.

**Tells:** proposal says "sign", "hash anchor", "digest", or "receipt" over MCP output; no external oracle or out-of-band channel mentioned; rogue MCP is explicitly in the threat model.

<!-- promote-candidate:rogue-mcp -->
When a threat model explicitly names a rogue/colluding MCP as adversary, any integrity proof (hash digest, signature, receipt) that the MCP generates over its own output is structurally defeated at zero cost: the rogue MCP fabricates both the payload and the proof simultaneously. Integrity verification for enumerated sets (validator vote-pubkeys, super-representative entries, RPC endpoint lists) sourced from an MCP must be anchored at an external authority the MCP cannot influence — e.g., a pinned external URL fetched independently by the skill or agent layer (stakewiz.app, tronscan.org/#/sr, chainlist.org), or a durable-binding object whose authority was established outside the MCP bound
[…truncated]

<!-- run:run-2026-05-05T19-14-11-189Z issue:#565 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verification channel must be independent of the named adversary — rogue-MCP self-attestation antipattern

**When the threat model names a component as the adversary, any verification path that flows through that same component provides zero security uplift.**

**Why:** MCP-side per-session response signing is the canonical self-attestation antipattern — a rogue MCP that fabricates data can equally fabricate its own signatures. Skill-side multi-source consensus via 'second RPC / Chainlink / multi-RPC' still routes through MCP tool calls, so the rogue MCP controls every vote in the consensus. Both patterns have precedent in prior pushbacks.

**How to apply:** Before accepting any integrity-check proposal against a rogue-MCP threat, confirm the verification channel is structurally independent of that adversary (out-of-band oracle, on-chain proof, cooperating agent with separate credentials and a separate process boundary). If not independent, push back and ask the requester to pick a framing: (1) subsume into an already-open parent issue, (2) re-scope as skill guidance with an explicit rogue-agent scope label filed in the correct repo, or (3) reclassify from `security_finding` to observability/UX.

**Tells:** `security_finding` + `read-only-data-plane` labels together; mitigations proposing MCP-side signing or consensus fetched via MCP tool calls; threat model explicitly names the MCP server as the adversary.

<!-- promote-candidate:data-integrity -->
In MCP-based systems where the stated threat is a rogue MCP server, verification schemes that route through MCP tool calls (multi-RPC consensus, Chainlink-via-MCP, second-source fetch via MCP) remain fully under the adversary's control — the rogue MCP controls every input to the consensus. MCP-side per-session signing is equally ineffective: the component generating the signature is the same component generating the fabricated data. Structural independence (out-of-band oracle, on-chain verifiable proof, separate-process cooperating agent with independent credentials) is required before an integrity check provi
[…truncated]

<!-- run:run-2026-05-05T19-14-11-189Z issue:#562 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Yield-sanity checks at skill or prose layer cannot defend against rogue-agent threats

**Before implementing any 'yield feasibility gate', explicitly place it in one of three enforcement layers: (1) skill/prompt rules — text in the agent's context, bypassed by a rogue; (2) MCP tool hooks — intercept tool calls but never advisory prose; (3) hard cap inside the yield tool itself — the only unconditionally enforceable position for a cooperative MCP.**

**Why:** Proposals phrased as 'skill calls canonical estimator when prose APY > 2×' conflate all three layers. A rogue agent never reaches the skill rule. MCP has no prose-intercept hook. Using `compare_yields` to validate `compare_yields` output is circular — enforcer and suspect share the same trust boundary.

**How to apply:** For every yield-anomaly gate issue, name the threat actor (cooperative mistake vs. rogue) and check whether the proposed enforcer is inside or outside that actor's control. If inside, push back with three alternatives: (a) architectural close (no code for rogue paths), (b) skill guidance for cooperative path only, (c) hard cap inside the tool.

**Tells:** Issue title mentions 'yield too good to be true', 'MCP-side feasibility', or 'refuse if APY exceeds'; proposed fix describes a skill rule calling an estimator on agent prose; issue labeled `tool_gap` but threat is actually rogue-agent.

<!-- promote-candidate:yield-anomaly -->
In the vaultpilot-mcp stack, the MCP tool layer intercepts only tool calls — it has no hook into advisory prose emitted by the agent in its response. Yield feasibility gates written as skill rules (prompt-layer text) are transparent to a rogue agent that chooses to ignore them. A yield-validation tool that cross-checks its output using a sibling tool on the same MCP server shares the same trust boundary as the value being checked, providing no independent safety guarantee.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T19-14-11-189Z issue:#566 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Self-reported provenance footers are theatrical against rogue-MCP threats until an integrity mechanism exists

**A `data_provenance` footer on an MCP tool is a display artifact, not a security control.** A rogue MCP fabricates `rpc_provider`, `block_height`, `fetch_timestamp`, and `source_count` at the same trivial cost as the balance itself — the footer is theatrical against the exact threat it claims to address.

**Why:** Shipping provenance UI ahead of the backing integrity mechanism (response signing, skill-side multi-RPC consensus) inverts the dependency. Every footer before consensus exists renders `source_count: single`, training users to ignore the field before it becomes meaningful. Self-reported metadata cannot attest to its own trustworthiness.

**How to apply:** When a ticket proposes a provenance footer as a security measure on a read-only data-plane tool, verify an out-of-band integrity mechanism already exists. If not, push back and propose folding the UI into the integrity issue so they ship as one artifact — or narrow MCP scope to the one chain-locked field (e.g. `block_height`) the user can independently verify on a public explorer.

**Tells:** labels `security_finding` + `data-provenance` together; threat model names a rogue or compromised MCP server; no signing or multi-source consensus PR is open yet.

<!-- promote-candidate:rogue-mcp-threat-model -->
Self-reported MCP tool output fields (`rpc_provider`, `source_count`, `fetch_timestamp`) are fabricatable by a rogue MCP at the same trivial cost as the domain data those fields annotate. A provenance footer on a read-only data-plane tool provides no integrity guarantee against a compromised server. Its value is only realized once an out-of-band mechanism — response signing, cooperating-agent multi-RPC consensus, or a chain-verifiable field like `block_height` — backs the claim. Shipping the display field ahead of the mechanism trains users to trust a field before it is trustworthy.
<!-- /promote-candidate -->

<!-- run:run-2026-05-01T13-48-07-936Z issue:#558 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Cross-RPC divergence checks must use a reference provider from a different trust domain and field-specific comparison

**When building any RPC-integrity or chain-data divergence check, the reference provider must be outside the trust domain of the suspected-rogue endpoint, and comparison must be field-specific — not byte-equality.**

**Why:** A rogue RPC can fabricate consistent responses to *both* a primary and reference call if they share a trust boundary (e.g., routing a "Chainlink check" through the same provider being defended against is circular — the adversary controls both answers). Separately, byte-equality cross-provider comparison produces spurious divergence on fast chains due to 1-block fork drift between fetches.

**How to apply:** Before designing any cross-provider verification mechanism, explicitly map the trust domain of each provider. If the reference source overlaps with the adversarial threat model, reject the design and escalate for an independent oracle or a public gateway with a distinct operator. Replace raw-response byte-equality with field-extracted comparison (e.g., LLTV, oracle address, IRM address pulled individually).

**Tells:** Proposed check fetches both values from the same configured endpoint or the same operator's infrastructure; issue mentions "verify via Chainlink" or "second RPC call" without specifying provider independence; spec uses `===` or byte-diff on full RPC response objects.

**Escalation:** If no genuinely independent reference source is available, the mechanism should be scoped down or deferred rather than shipped with a circular trust chain — a false sense of verification is worse than an acknowledged gap.

<!-- run:run-2026-05-01T13-48-07-936Z issue:#565 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Integrity-check proposals for rogue-component threats must be validated for trust-domain independence before any code...

**Never accept a proposed integrity fix for a rogue-MCP / rogue-agent threat without first tracing the full verification chain to confirm it is independent of the suspected rogue party.**

**Why:** A signer whose key is controlled by the rogue component, or a cross-check whose data plane passes through that component, is null security — the attacker fabricates response and proof together. This is easy to miss when the fix looks structurally correct ("sign responses", "validate against a second source") but the second source is reachable via the same compromised path.

**How to apply:** For any issue tagged `rogue-mcp`, `rogue-agent-triage`, or carrying a security label where the threat actor *is* a component in the system, map the proposed fix's trust chain end-to-end before approving. If any link in that chain touches the threat actor's data plane, push back immediately.

**Tells:** proposed fix adds signing or checksums; the signing key is generated or stored inside the component under suspicion; proposed "independent" RPC or oracle still routes through the same MCP layer; a parallel issue is still designing the independent-verification primitive.

**When pushing back**, offer concrete framings: (1) escalate as architectural residual risk, (2) scope down to cooperating-agent provenance only, or (3) defer until the independent-verification primitive is settled — then ask the author which compromise model to ship against before writing any code.

<!-- run:run-2026-05-01T14-48-57-664Z issue:#593 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Security fixes that self-verify through the attacked component violate cross-trust-domain independence

**Never accept a fix that routes threat verification through the same trust domain the attacker controls.** Allowlists, fingerprint tools, preflight gates, or in-process validation placed inside a potentially-compromised component cannot constrain the adversary — the attacker controls the defense.

**Why:** A rogue-MCP or rogue-agent threat makes every tool, schema, and allowlist inside that process suspect. Adding in-process verification gives the attacker authority over the check meant to stop them. This matches past precedent closing curated-allowlist and in-MCP security proposals as architectural residual risk.

**How to apply:** When a security issue proposes a new MCP tool, allowlist, or preflight gate and the labeled threat is a compromised MCP/agent, push back. Offer three paths: (1) close as architectural residual risk mirroring prior closures; (2) re-scope the fix to a genuinely independent trust domain with an explicit boundary statement; (3) offer a narrow schema-tightening change that is orthogonal to the threat model.

**Tells:** Issue labels include `rogue-mcp`, `rogue-agent-triage`, or `trust-boundary`; proposed fix is a new in-repo tool or in-process allowlist; the same agent the fix is meant to defend against could invoke the defense.

<!-- run:run-2026-05-05T19-14-11-189Z issue:#558 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Proposed integrity checks for rogue-component threats must not route through the suspected component

**Before implementing any 'cross-check' or 'divergence check' proposed as the fix for a rogue-RPC / rogue-MCP threat, audit two properties: (1) the verifying path uses a trust domain provably disjoint from the suspected component; (2) the equality criterion tolerates legitimate state drift between sequential on-chain reads.**

**Why:** A 'cross-check against Chainlink' that still issues the verification call through the same `rpcUrl` operator is circular — a rogue endpoint fabricates both responses consistently. Independently, 'byte-for-byte equality between two providers' yields false positives from normal 1-block drift between sequentially issued calls.

**How to apply:** When a security issue proposes validation-by-comparison for on-chain market params (LLTV, oracle price, exchange rate, IRM address), trace the full call path for both legs before writing code. If both legs share the same operator or URL family, push back and offer: (A) operator-distinct providers with field-specific (not byte-level) comparison, (B) a trust-domain-clean sanity bound (e.g., yield-feasibility range check), or (C) documented residual-risk deferral.

**Tells:** Issue title mentions 'divergence check' or 'cross-check'; proposed fix queries the same `rpcUrl` for primary and verification reads; labels include `security_finding` alongside `rogue-rpc` or `rogue-mcp`.

<!-- promote-candidate:trust-domain-independence -->
When a proposed on-chain integrity check issues both the primary read and the verification read through the same RPC endpoint (same `rpcUrl` or same operator family), a rogue endpoint can fabricate both responses consistently, making the check circular with zero security benefit. Additionally, byte-for-byte equality between two sequential RPC calls on live chain data is not a reliable divergence signal because 1-block drift between calls produces legitimate divergence for any mutable field (exchange rate, oracle price). Field-specific numeric-tolerance compa
[…truncated]

<!-- run:run-2026-05-01T13-20-53-983Z issue:#561 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify tool input schemas before implementing security-invariant gates on named parameters

**Read the actual schema definition of the targeted tool before writing any enforcement code for a security invariant.** Security bug reports often assume a parameter type (e.g., `addressOrLabel`) is accepted by a tool when the real schema only accepts regex-validated literals — silently installing a guard on a non-existent parameter does nothing and wastes a fix slot.

**Why:** A well-formed invariant report (Inv #N, named tool, named parameter, proposed gate) can have a false premise that is invisible until you grep the schema. Discovering this after implementing wastes review cycles and can introduce dead code near security-critical paths.

**How to apply:** When an issue asks you to add re-derivation, rate-limiting, or any enforcement on `tool.param`, do `grep -n 'param\|schema' src/**/<tool>.ts` and read the `Input` type before touching implementation. If the parameter doesn't exist as described, push back with the schema line reference and a precise statement of what the tool actually accepts.

**Tells:** Issue cites an invariant number, names a specific tool + parameter, proposes a 'gate' or 'enforcement step', and links to a threat-model doc. Also: proposed defense routes through the same trust boundary as the adversary (e.g., requiring a `list_contacts` call to validate labels when the rogue-MCP also controls `list_contacts`) — flag this circularity explicitly in the pushback.

<!-- run:run-2026-05-01T17-27-23-838Z issue:#593 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify actual tool input-validation code before accepting a security report's claimed attack surface

**Before treating a reported injection or override surface as real, inspect the tool's runtime validation code — the surface the reporter describes may not exist in the current implementation.**
**Why:** An issue claimed `set_helius_api_key` / `set_etherscan_api_key` provided arbitrary-URL injection with 'zero invariants'; `runtime-rpc-overrides.ts` lines 164-169 explicitly reject URL/scheme inputs — the surface did not exist. Accepting an overstated premise inflates severity, wastes fix cycles, and can trigger unnecessary architectural escalations.
**How to apply:** Any time a security issue says a tool 'accepts arbitrary X,' 'has no invariants,' or 'lacks validation,' grep the tool handler and every referenced validation helper for the claimed input class before confirming the premise. Confirm or deny in the triage comment with a specific file:line citation.
**Tells:** Title contains 'zero invariants' / 'no validation' / 'arbitrary input'; labels include `security_finding`; no specific code line cited proving the gap; tool names sound mutable (`set_*`, `configure_*`, `switch_*`); report describes threat model in terms of what the tool *could* do rather than what it currently does.

<!-- run:run-2026-05-01T18-04-35-881Z issue:#614 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Audit the existing implementation before accepting a bug report's premise about missing behavior

**Rule:** When a report claims 'endpoint X never probes Y,' trace the full execution path — SDK restore hooks, background timers, per-request guards — before accepting the gap as real or writing new code.
**Why:** Reporters see a surface symptom (e.g., a stale status field, an opaque error string) without knowing the underlying pipeline. Accepting the premise unchecked risks duplicating existing probes, masking the real root cause, and growing technical debt.
**How to apply:** Grep the relevant subsystem for the claimed missing behavior first. If the behavior already exists at multiple layers, the reporter's proposed fix is likely mis-targeted; redirect attention to the actual anomaly (e.g., error serialization, rendering, asymmetric code paths).
**Tells:** Report proposes adding a probe or check to a thin status/health function; related issues already exist for the same symptom class; the reported error output (e.g., `[object Object]`) doesn't match what a missing-probe failure would produce.
**Secondary signal:** An opaque stringified error (`[object Object]`) in a codebase with typed error classes is its own bug — suggest retargeting to error rendering before adding new checks.

<!-- run:run-2026-05-05T19-14-11-189Z issue:#561 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify actual MCP tool schemas before accepting security-finding premises about parameter types

**When a security report claims an MCP tool accepts a specific parameter variant (e.g. `addressOrLabel`), read the actual `schemas.ts` before accepting the premise.**
**Why:** Issues have asserted label-resolution paths in tools that only accept regex-validated literal addresses; a false schema premise wastes triage effort and risks spawning duplicate skill issues against a threat vector that doesn't exist at the MCP boundary.
**How to apply:** For any `security_finding` or `bug_report` whose core claim hinges on a specific parameter name or type, grep the relevant schema file first. If the parameter doesn't exist, push back immediately and cite the schema line range.
**Tells:** Issue title names a compound parameter variant (e.g. `addressOrLabel`, `recipientOrAlias`); labels include `security_finding`; named tools are MCP boundary tools.

<!-- promote-candidate:rogue-mcp-self-attestation -->
A proposed security gate that routes enforcement through the same trust channel as the adversary provides no real protection. When the threat model is a rogue MCP server, requiring a prior call to another MCP tool (e.g. list_contacts) as a pre-condition is ineffective — the rogue server can fabricate both the spoofed decoration and a gate-bypass response. Effective enforcement must occur at a layer the adversary cannot control: cryptographic verification, out-of-band re-derivation, or schema-enforced literal-address validation at the MCP boundary itself.
<!-- /promote-candidate -->

**Also:** Before accepting a "missing control" finding, audit existing defenses (`assertNoAddressLeak`, regex-validated address fields) — they often already block the stated vector by construction.

<!-- run:run-2026-05-05T19-14-11-189Z issue:#559 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Skill-side mandates don't defend Role-A rogue-agent attacks — fix layer must exceed attacker's trust boundary

**When a repro frames the attacker as the invoking agent itself (Role-A / rogue-agent), skill-side mandates or advisories provide zero marginal defense** — the hostile agent ignores them exactly as it ignored any existing advisory.
**Why:** A rogue agent controls when and whether it calls any skill tool; a "skill must call X before Y" rule is bypassed trivially by simply not calling it. The fix layer must sit above the attacker's control plane: MCP-side state gates, Role-B out-of-band verification, or an architectural close are the only meaningful options.
**How to apply:** On any `security_finding` issue, first classify the threat — cooperative-agent (Role-B, fix lives in skill) vs. rogue-agent (Role-A, skill-side fix is inert). If rogue-agent, push back on skill-side fixes and surface three options: (a) close architectural, (b) reframe as cooperative-agent variant filed at the correct repo/layer with explicit Role-B scope, (c) add an MCP-side session-state gate.
**Tells:** `security_finding` label; repro says "agent + MCP coordinate-attack" or "agent chose not to invoke"; suggested fix is "skill should require/mandate X before advancing to Y".

<!-- promote-candidate:advisory-layer -->
In vaultpilot's opaque-calldata flows, skill-side advisories ("extra-vigilant, not mandatory") and skill-side mandates are both neutralized by a rogue Role-A agent because the agent controls skill invocation entirely. An advisory that a cooperative agent honors becomes a no-op when the agent itself is the attacker. MCP-side session-state gates — tracking whether `get_verification_artifact` was called before `preview_send` inside the MCP server's own state — are the only enforcement point that survives a Role-A attack in this architecture.
<!-- /promote-candidate -->

<!-- run:run-2026-05-01T14-48-57-664Z issue:#600 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## MCP-side checks do not defend against rogue-MCP threats — validate the trust boundary before accepting a mitigation

**When a security finding proposes adding validation on the MCP/server side to defend against a colluding or compromised MCP, reject it as tautological.** A rogue-MCP fabricates both the payload and the check result; placing the validator on the attacked boundary provides zero net defense.

**Why:** A proposed "server-side election-state digest" extension was structurally circular — the same fabrication path that corrupts witness rankings also corrupts any MCP-emitted digest. The relevant invariant for rogue-MCP scenarios is always on the *skill* side (durable-binding source-of-truth), not the MCP side.

**How to apply:** Before implementing any mitigation, identify which trust boundary is being attacked. If the proposed fix lives inside that boundary, flag tautological and redirect to the skill-side gap — typically a durable-binding kind in `src/security/durable-binding.ts` (Inv #15) or a device-firmware blind-sign architectural limit (Role-C).

**Tells:** Proposed fix is "extend [MCP/server/oracle] to also verify [value that same component already provides]"; labels include `set-level-collude`, `role-c`, or `ledger-blind-sign`; threat model names a colluding MCP or server.

Also verify before acting: (a) scan existing durable-binding closed-enum kinds for coverage already in place; (b) search for closed won't-fix duplicates on the same blind-sign architectural limit before re-implementing; (c) confirm the canonical multi-surface tracking issue before opening a new one.

<!-- run:run-2026-05-01T17-27-23-838Z issue:#591 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## RPC-endpoint-origin threats are skill-side pin rules, not MCP-side invariant extensions

**Rule:** When an issue proposes an MCP-side defense (digest, signature, or hash-anchor) against a 'MCP could return a falsified RPC / connection endpoint' threat, push back and reroute: the correct fix is a skill-side 'pin to curated registry, refuse MCP-emitted URLs' rule, filed as a `cross-repo-scope-split` in the skill repo with cooperating-agent-only scope.
**Why:** Any proof the MCP emits over the same URL set it controls is tautological — a colluding MCP fabricates both the URL and the accompanying digest from inside the same trust boundary. The defense must live outside that boundary (skill layer, curated registry) to have any bite.
**How to apply:** On any issue asking to extend an MCP-side invariant (e.g. Inv #14 or equivalent) to cover RPC / validator / SR endpoint enumeration, decompose the cells first: items already covered by existing `durable-binding` kinds get closed as duplicate-of-design; the endpoint-switch cell gets rerouted skill-side.
**Tells:** issue proposes MCP 'prefix the set with a signed digest'; threat is described as validator/RPC node selection emitted by the MCP; tags include `rpc-endpoint-pinning`, `set-level-collude`, or `inv-14`.
**Recommended triage output:** (1) close MCP-side request as tautological, (2) open skill-side issue for curated-registry pin, (3) confirm with user before filing the skill-side issue if scope is ambiguous.

<!-- run:run-2026-05-01T17-27-23-838Z issue:#600 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Reject tautological mitigations when the attacker controls both data and its attestation

**Never accept a proposed integrity check whose attestation is sourced from the same component the threat model names as the adversary.** A rogue MCP can fabricate both the data it returns (e.g. a validator/witness list) and any digest, block-anchored hash, or signed proof it emits over that same data — adding the digest to an invariant provides zero additional trust.

**Why:** Block-anchored or hash-extended defenses implemented inside a compromised trust boundary are circular: the attacker controls the input, the hash, and the claimed provenance simultaneously. The net security delta is zero.

**How to apply:** Before implementing or approving any MCP-side integrity extension, ask: 'Does the verifier trust the same component the threat model names as the adversary?' If yes, reject or re-scope to an out-of-band trust anchor — hardware attestation, an independent RPC the agent pins separately, or on-device clear-sign verification.

**Tells:** Issue proposes 'MCP emits an anchored digest / signed proof of its own output'; threat model explicitly names rogue-MCP or colluding agent; proposed fix introduces no external oracle or hardware anchor; existing invariant already names the at-risk address kind with a public-provenance hint.
