# Tailored CLAUDE.md for issue #649 (szhygulin/vaultpilot-mcp)

Built by `research/curve-redo-bundle/super-agent-tailored/build-tailored-agents.cjs`.
Source: `research/curve-redo-bundle/super-agent/agent-super.CLAUDE.md` (122 sections).
Selector: claude-opus-4-7[1m]; kept 21/122 sections.

<!-- run:run-2026-05-02T06-32-08-433Z issue:#38 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Push back on issues that bundle multiple architectural layers into one PR

**When a feature plan touches ≥ 3 distinct layers** (e.g., LLM prompt design, new state-machine values, orchestrator branching, CLI surface, and cost surfacing all at once), refuse to implement the full scope in a single pass and instead propose a numbered phase split.

**Why:** Multi-layer issues produce 500+ LOC diffs across 8+ files with two or more LLM prompts that are nearly impossible to review or iterate on together. Each phase should deliver standalone value so the user can stop after any phase.

**How to apply:** Before writing any code, count the distinct architectural concerns (prompt design, type changes, orchestration logic, CLI, cost display, etc.). If the count exceeds 2, draft a phase breakdown and post it as a comment asking which scope the user wants before touching code.

**Tells:**
- Feature plan file exists and lists 5+ bullet sub-features
- Issue labels include both an LLM/AI concern and an orchestrator/CLI concern simultaneously
- Estimated LOC across files exceeds ~300 before any implementation begins

**Phase split heuristic:** Phase 1 = consumption of existing artifacts with zero new state; Phase 2 = new state machine + core logic; Phase 3 = user-facing CLI + cost/preview surface.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#38 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Inject pre-written feature-plans into the agent seed as authoritative design guidance, before the workflow block

**Glob `feature-plans/issue-<N>-*.md` in the worktree and, when a match exists, append its content as a named section between the agent's CLAUDE.md and the workflow block, marked 'authoritative design guidance'.**
**Why:** Without an explicit upfront plan, coding agents reinvent file layouts and architecture from scratch on every run, causing design drift across reruns and wasted tokens re-litigating structure already decided by a human architect.
**How to apply:** Any change to `buildAgentSystemPrompt()` or equivalent prompt-assembly entry points should preserve and sit below this plan-injection step; once a plan file is committed to `feature-plans/`, it takes effect on the next run with zero other infrastructure.
**Tells:** An issue has a matching `feature-plans/` file already committed; the prompt assembly doesn't reference it yet; or the agent's proposed file layout diverges from the pre-written plan.
**Ordering discipline:** Ship the plan-consumption path (reading existing files) before the plan-production path (live Opus planner, complexity gate, orchestrator state). Hand-written plans already exist and pay off immediately; the planner that generates them is a separate, deferrable phase.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#56 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify dependency PR merge status before implementing features that build on them

**Rule:** Before starting implementation of any issue that cites upstream PRs as prerequisites, confirm each cited PR is actually merged to `main` (not just closed or open) by checking `gh pr view <N> --json state,mergedAt`.

**Why:** Issue bodies can misstate PR status (e.g., 'PR #50 merged' when it was closed-unmerged). Building on absent foundations wastes effort and produces dead code — or worse, silently diverges from actual `main` behavior.

**How to apply:** Any time an issue references prior PRs, task numbers, or preceding agents' work as a prerequisite for the new feature, run the status check before touching any source file. If a dependency is missing, push back with a concrete list of blocked items and offer alternatives (block, reframe, or stub).

**Tells:**
- Issue body contains phrases like 'after PR #N is merged', 'depends on', 'builds on', or references specific outcome types / data structures not visible in `HEAD`.
- Grep for the key symbols (functions, types, file paths) introduced by the cited PR returns no results on `main`.

<!-- run:run-2026-05-02T06-32-08-433Z issue:#31 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## When a feature has multiple detection modes, defer any branch whose input signal does not yet exist

**Ship only the detection branches that are fully grounded by signals available today; leave schema fields and apply-branches for the PR that adds the missing signal.**

**Why:** Pre-building dead-code branches and registry fields (e.g., `retiredAt`, `retireReason`) for a mode that can never fire yet adds maintenance surface, misleads reviewers about feature completeness, and risks schema drift by the time the upstream signal actually ships.

**How to apply:** Before building each detection branch, confirm its input signal exists in the codebase or is delivered in the same PR. If it isn't, record the upstream gate explicitly in PR scope notes and emit zero proposals from that branch — do not stub it.

**Tells:** Issue covers two related cleanup actions (e.g., merge vs. retire); one action is gated on outcome metrics from a future issue; the temptation is to add stubs or empty schema keys "for completeness."

**Corollary:** A detection subcommand that emits zero proposals today because its signal hasn't landed is correct behavior, not a gap — document it as intentional rather than apologizing for it.

<!-- run:run-2026-05-02T10-31-33-192Z issue:#36 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Omit schema fields whose upstream producer does not yet exist

**When extending a data schema or adding a new one, leave out any field whose input signal has no upstream producer yet — even if the issue spec lists it.** Ship with only the fields that can be fully populated by existing code.
**Why:** A stub field (always `null`, always `0`) misleads downstream consumers and auditors into believing a data flow exists. It also creates schema churn: the field must be re-introduced, re-typed, and re-documented when the real signal arrives.
**How to apply:** If a field is gated on a sister issue that hasn't shipped, record the omission explicitly in the PR description and scope notes (e.g. 'costUsd omitted; joins schema in the PR that ships #34'). The field's owning PR adds it atomically with the producer.
**Tells:** Field names tied to a sibling tracking issue still open; columns like `$/merge` or `cost-per-X` when no cost-capture module exists yet; spec language like 'once #N lands'.
**Contrast:** Do not add `// TODO: populate when #N ships` placeholders in the schema type — the absence of the field is the correct state until the producer exists.

<!-- run:run-2026-05-03T05-54-13-869Z issue:#54 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Deduplicate cross-module parsers into a typed util with Zod schema and smoke tests

**When two or more modules contain near-identical parsing or transformation logic, extract it into `src/util/` as a single generic typed helper rather than letting copies diverge.**

**Why:** Diverging copies accumulate subtle differences silently — a resilience fix applied to one copy is missed in the others. Four independent `parseJsonLoose` implementations had drifted from each other, meaning bugs fixed in one were still present elsewhere.

**How to apply:** On any refactor touching parsing/serialization in 2+ modules: (1) audit for duplicate logic first, (2) extract to `src/util/<helperName>.ts` with a generic `<T>` and a Zod schema parameter for runtime validation, (3) add a comprehensive smoke-test file covering all input variants (bare object, fenced-tagged, fenced-untagged, stray brace, malformed JSON, schema mismatch), (4) wire `npm test` in `package.json` and add the CI step in the same commit.

**Tells:** Multiple files each define their own `parseJson*` or `extract*` helper; they share recognizable three-candidate logic (bare / fenced-tagged / fenced-untagged) but live in separate modules; the functions have drifted in minor ways (whitespace handling, error return shape).

<!-- run:run-2026-05-04T14-37-10-004Z issue:#33 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Consolidate commit-phase steps to avoid turn exhaustion before final git commit

**After tests pass, commit within 2 turns: combine `git add` and `git commit -m "..."` in one Bash call — no interim diff reviews, no temp-file message drafts, no redundant `git status` or `git fetch` calls.**
**Why:** Agents burn turns in the cleanup phase (reviewing diffs of already-reviewed files, writing commit messages to `/tmp/`, re-running builds that just passed) and hit the 50-turn ceiling before issuing `git commit`, leaving complete, tested work uncommitted.
**How to apply:** The moment `npm test` (or equivalent) is green and you know which files changed, issue `git add -A && git commit -m "<message>"` immediately — one Bash call. Don't split staging, committing, and verification across separate turns.
**Tells:** Last tool calls show ≥3 consecutive git diff / git status / git fetch / Write-to-/tmp/ calls with no `git commit` issued — the agent is in stall-loop review mode after implementation is already done.
**Guard rule:** Never write a commit message to a temp file; write it inline. Never re-run a build that just passed clean. If you catch yourself doing either, skip straight to the commit call.

<!-- run:run-2026-05-05T16-51-01-872Z issue:#133 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## When an issue body self-proposes a phase split, treat that split as mandatory at pre-dispatch

**When an issue body contains an explicit phase-split or 'Suggested implementation split' section, push back on the combined scope — the split is mandatory, not advisory.**

**Why:** Issue authors who pre-propose splits have already diagnosed over-scoping; dispatching the combined scope burns turns on a predictable rejection and duplicates the author's own analysis.

**How to apply:** During pre-dispatch scope-fit check, scan the issue body for phase-split language ('Phase 1/2', 'Suggested split', 'dependency seam', 'imports X constant'). Evaluate each phase independently against the 5-file threshold (with 1.5× calibration). Name the dependency seam explicitly in the pushback comment and recommend filing as sequential issues, citing any prior split pattern (e.g., #34 → #85+#86) as precedent.

**Tells:** 'Phase 1', 'Phase 2', 'Suggested implementation split', 'clean dependency seam', 'imports [Phase 1 export]' anywhere in the issue body.

**Bonus sweep:** Grep `src/` for the relevant model/constant patterns during scope inspection — issue authors routinely miss 1–2 files that belong in Phase 1's migration list. Name them in the pushback so re-filed issues are complete from the start.

<!-- promote-candidate:pre-dispatch-scope-fit -->
Issue bodies that contain explicit 'Phase 1 / Phase 2' or 'Suggested implementation split' sections reliably signal that the combined scope exceeds the per-issue budget. Each such issue tends to have a named dependency seam (e.g., Phase 2 imports a constant exported by Phase 1). The combined stated file count, after the 1.5x under-count calibration, consistently lands above the 5-file pre-dispatch threshold. Grepping source files for the relevant model/constant patterns during scope inspection typically surfaces 1–2 additional files the issue author omitted; these belong in the first phase's migration list. Recommending sequential issue filing with the dependency seam named in the pushback comment is the correct resolutio
[…truncated]

<!-- run:run-2026-05-05T22-03-52-041Z issue:#169 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Self-proposed phase split in an issue body is a mandatory scope boundary

**When an issue body itself proposes a Phase A / Phase B split with a named dependency seam, that self-proposed split is mandatory — push back and require two sequential issues before any implementation begins.**
**Why:** An author who names the sequencing dependency inside the combined issue is signaling scope overload. Bundling both phases in one dispatch defeats the stated precondition (e.g., the advisory dry-run must exercise real agent files before the destructive `--apply` sibling ships), and prior compact-feature precedent shows a single phase alone produces 700–800 lines of source + test.
**How to apply:** At pre-dispatch, scan the issue body for self-proposed splits. If a dependency is named — especially advisory-before-destructive — push back regardless of apparent implementation size or the author's intent to 'just combine them for convenience'.
**Tells:** Phrases like 'Phase A / Phase B', 'advisory predecessor', 'don't repeat the mistake of shipping the destructive sibling', or paired `--dry-run` / `--apply` with an explicit ordering note anywhere in the body.

<!-- promote-candidate:advisory-then-destructive -->
When a feature issue bundles an advisory (dry-run / read-only) phase with a destructive (write / apply) phase and explicitly names the sequencing dependency in its own body, the combined dispatch consistently fails the pre-dispatch scope-fit check. The advisory phase must be dispatched, merged, and exercised on real agent files before the destructive sibling is filed as a separate issue — not merely described as a future concern. A single advisory phase alone in this codebase has produced 700–800 lines of source and test; bundling both phases roughly doubles that before any safety validation has occurred on live data.
<!-- /promote-candidate -->

<!-- run:run-2026-05-02T10-31-33-192Z issue:#55 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify all named prerequisites are merged before implementing dependency-gated issues

**Rule:** When an issue explicitly defers to another (e.g. 'pick up after #N lands'), check *every* prerequisite — the blocking issue AND any data-source or infrastructure PRs it depends on — are merged to `main` before writing a single line of implementation code.

**Why:** Implementing half of a multi-part feature (e.g. surfacing triage cost with no projected-dispatch-cost anchor) can land a worse UX than doing nothing — partial cost surfaces, inconsistent UI rows, or silent scope expansion into undesigned territory.

**How to apply:** On any issue that contains phrases like 'depends on', 'pick up after', 'blocked by', or lists a sibling issue number in its body, run `gh issue view <dep>` and `gh pr list` to confirm merged state before proceeding. If any named dependency is still OPEN or its PR is unmerged, post a pushback with the specific gap and ask the user to choose: hold, expand scope, or accept a flagged skeleton.

**Tells:**
- Issue title or body contains 'depends on #N' or equivalent
- A data-source PR (e.g. one introducing a new field consumed by this issue) exists but is unmerged
- The issue describes UI output that requires a value only another issue's code will produce

<!-- run:run-2026-05-04T14-37-10-004Z issue:#55 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Break dependency-chain stalls by making the missing anchor field optional and omitting its display row

**Rule:** When an issue's display row depends on an upstream that is itself blocked, add the dependent value as an *optional* field on the shared struct, gate the rendered row on *presence* (not on zero), and ship the issue standalone with a scope note that the upstream will slot in when it lands.

**Why:** A stalled upstream can block an otherwise self-contained change indefinitely. Making the field optional decouples the two issues: the row simply doesn't appear until the upstream ships, which is the correct UX — a zero-valued or 'N/A' row would be worse than no row.

**How to apply:** Identify whether the blocked dependency is *strictly required* or only needed for one display row. If the latter, scope the issue to the optional-field pattern, note the integration point in a `scopeNotes` comment, and proceed. Update tests to assert the row is absent (not zero) when the field is undefined.

**Tells:** Issue title says 'depends on #N'; the dependency is marked blocked or awaiting another fix; the missing data is already logged elsewhere and only needs to be threaded to the UI.

<!-- run:run-2026-05-05T14-26-37-251Z issue:#636 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Fee preview in prepare_* responses: position first, store native+USD, return null on failure

**Place `renderCostPreviewBlock` output at the top of every `prepare_*` response, ahead of VERIFY BEFORE SIGNING and the full verification stack.** Users can abort on fee shock fastest when the cost line is the first thing they read; burying it below a long crosscheck table wastes attention they've already spent.
**Why:** The verification render pipeline historically emitted VERIFY BEFORE SIGNING first, so a surprising fee was only visible after the user had already read the whole block.
**How to apply:** Any new `prepare_*` handler or render-pipeline change must place the cost block first. Chain handlers that lack a precomputed cost field (TRON, Solana, BTC, LTC) must omit the block entirely rather than fabricate one — `renderCostPreviewBlock` returns `null` on estimation failure, not `"~$0.00"`.
**`enrichTx` must store both `gasCostUsd` (USD float) and `gasCostNative` (string, 18-decimal normalized).** When the USD price feed degrades, the renderer falls back to native-only display; when gas estimation itself failed, it stays silent.
**Tells:** price-oracle timeout in `enrichTx`; `gasCostUsd` absent but `gasCostNative` present; adding a new EVM `prepare_*` handler; touching the render-verification pipeline.

<!-- promote-candidate:evm-cost -->
EVM `prepare_*` handlers have precomputed `gasCostUsd` and `gasCostNative` fields available after `enrichTx`; TRON, Solana, BTC, and LTC do not share this field shape and require separate fee-surfacing implementations. Rendering a cost preview line for EVM can be done with a single `renderCostPreviewBlock(enrichedTx)` call that returns null on estimation failure rather than a fabricated figure. The dual-field pattern (USD float + native string at 18 decimals) allows graceful degradation when price oracles are unavailable.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T19-14-11-189Z issue:#650 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Thread every chain-queried fee field into the stash struct at pin time, not at render time

**When a new render block needs a live-chain value (e.g. `baseFeePerGas`), add that field to every stash / cached-pin struct at the moment the RPC call already happens — never re-fetch it downstream.**

**Why:** `baseFeePerGas` was queried at `pinSendFields` time but absent from `StashedPin`; cached re-pins silently dropped the EIP-1559 cost breakdown because the original RPC response was no longer reachable at render time.

**How to apply:** Before wiring a new renderer that consumes a chain-derived value, trace the data flow back to every struct that can short-circuit the RPC path (stash, cache, re-pin) and add the field there — parallel to already-stored siblings like `maxFeePerGas` or `gas`.

**Tells:** Renderer needs `baseFeePerGas` / `effectiveGasPrice` / `gasCostNative`; stash already carries `maxFeePerGas`, `nonce`, or `gas`; the pipeline has a pin phase that can be replayed from cache.

<!-- promote-candidate:eip-1559 -->
EIP-1559 cost blocks rendered at `preview_send` use the pinned tuple (baseFeePerGas + maxPriorityFeePerGas + gas) stored in `StashedPin`. effectiveGasPrice = baseFee + priority (capped at maxFee). The cost block is positioned as the FIRST human-readable block on a successful preview_send response so fee-shock signals are visible before the transaction hash. All three values (baseFeePerGas, gasCostNative, gasCostUsd) are computed once at pin time and forwarded through the envelope — no extra RPC call at render time.
<!-- /promote-candidate -->

<!-- run:run-2026-05-04T14-37-10-004Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Thread-through parameter changes exhaust turn budget when edited site-by-site

**When plumbing a new option end-to-end (CLI flag → interface → parse → propagate → runtime use), enumerate every change site up front and batch all edits into the fewest possible tool calls before touching any file.**

**Why:** Each granular Edit call costs one turn. A 5-site thread-through (option declaration, interface field, profile merge, run-params spread, logger log) plus build + test + commit + push + PR creation requires ~15 turns at minimum. Executing those same changes as N small targeted edits can consume 35+ turns, leaving no budget for the finalization steps — agent crashes at "all tests pass, committing" with zero turns left.

**How to apply:** On any issue whose title implies adding a flag, limit, ceiling, or config knob: (1) read all relevant files first, (2) write a mental edit plan listing every location, (3) apply each file's changes in a single large Edit or Write, never one field at a time. Reserve at least 8 turns for build → test → commit → push → PR before making the first code change.

**Tells:** Issue title contains "ceiling", "limit", "option", "per-run", "config"; implementation touches a CLI parser, a typed options interface, and one or more downstream call sites — the combination signals a multi-site thread-through.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#84 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Multi-file flag propagation exhausts turn budget when edits are piecemeal

**When threading a new CLI flag through 5+ files, prefer full-file `Write` or large batched `Edit` calls over many small sequential edits.**

**Why:** Each `Edit` is a turn; a flag that propagates through CLI → interface → orchestrator → state → preview can require 20–30 edits before the first build check, burning most of the 50-turn budget and leaving no room for compilation errors or iteration.

**How to apply:** Before starting, enumerate every file to touch and estimate edits per file. If total estimated edits > 20, switch to full-file `Write` for the most-edited files. Alternatively, widen `old_string` to capture and replace an entire function signature or interface block in one call instead of editing one field at a time.

**Tells:** New option added to a shared interface that also appears in CLI opts, orchestrator params, dispatcher args, state serialization, and a preview formatter — classic fan-out propagation where each layer needs its own edit.

<!-- run:run-2026-05-05T14-26-37-251Z issue:#587 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Verify referenced artifacts exist before acting on tooling or aggregator bug reports

**Rule:** Before writing any code or fix for a bug report that names specific files, directories, or symbols, run a repo-wide scan (grep/find/`gh search code`) to confirm those artifacts actually exist in THIS repo. If the scan returns zero hits, treat the issue as potentially misfiled rather than inventing a duplicate implementation.

**Why:** An issue naming `tools/sample_matrix_run.py` and `runs/matrix-sampled/` was filed in the wrong repo; both paths were absent repo-wide. Implementing a phantom aggregator from scratch would have created maintenance-splitting debt and diverged from the canonical logic in the sibling repo.

**How to apply:** Whenever an issue references a concrete file path, module name, or CLI entrypoint — especially in `tools/`, `scripts/`, or a named sub-command — confirm the path exists before scoping work. If it doesn't exist, push back with three options: refile in the correct repo, file a doc-only sub-issue for any vocabulary/interface contract that does belong here, or close as misfiled.

**Tells:** Issue title names a specific script or aggregator; repo has no `tools/` directory or no Python sources; referenced symbols return zero grep hits across the entire worktree.

<!-- promote-candidate:misfiled-issue -->
When a bug report names a concrete file path or script (e.g. `tools/sample_matrix_run.py`) and that path returns zero hits in a repo-wide scan, the issue is almost certainly misfiled against a sibling repo. The correct handling is pushback with three explicit options: refile in the owning repo, file a doc-only sub-issue for any shared interface contract, or close as misfiled. Creating a duplicate implementation from scratch to satisfy the issue as filed splits maintenance and diverges from canonical logic.
<!-- /promote-candidate -->

<!-- run:run-2026-05-03T05-54-13-869Z issue:#62 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Commit-push-envelope must be consecutive turns; pre-commit verification burns kill the envelope

**After `git push` succeeds, emit the decision envelope in the very next turn — no intervening reads, greps, or build re-checks.**

**Why:** Agents that front-load exhaustive verification (build → typecheck → test → grep wiring checks) before the final commit+push consume most of the 50-turn budget. The push lands on turn 49 and there is no turn left to emit the envelope. The SDK sees an unfinished run and records a crash, discarding all the work even though the branch was pushed.

**How to apply:** Treat the final sequence as atomic and inviolable: `git add/commit` → `git push` → emit envelope. If optional validation (typecheck, test, grep cross-checks) hasn't been done yet, skip it rather than defer the envelope. The pushed branch is recoverable; a missing envelope is not.

**Tells:** Five or more of build/typecheck/test/grep calls appearing in the last 15 turns before the first commit attempt signals the budget is almost gone — stop verifying and push immediately.

**Corollary:** If the issue fix requires iterative build-fix cycles, do them in the first half of the turn budget. Reserve the second half for commit + push + envelope only.

<!-- run:run-2026-05-04T14-08-59-410Z issue:#34 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Batch multi-site edits into one Write per file to avoid turn-ceiling exhaustion on feature work

**When implementing a feature that touches many locations in a file, consolidate all changes into a single `Write` (full-file replacement) or the fewest possible `Edit` calls — never one `Edit` per change site.**

**Why:** The 50-turn SDK ceiling is consumed by granular per-hunk edits before implementation, tests, and CI verification can complete, causing the agent to crash without emitting an envelope. The pattern is self-defeating: the more carefully the agent edits, the less likely it finishes.

**How to apply:** Before touching a file, enumerate every change site; write them all in one pass. If turn count passes 30 with build/test not yet green, switch immediately to `Write` for each remaining file rather than continuing surgical edits.

**Tells:**
- 5+ sequential `Edit` calls to the same file in the visible tool log
- `npm run build` / `npm test` not reached until the final 2 turns
- Agent still adding interface fields or CLI options after turn 40

**Corollary:** For features requiring new CLI flags + new interfaces + new logic + new tests, treat each file as one atomic unit of work — read the full file, plan all changes mentally, write it once.

<!-- run:run-2026-05-05T11-30-15-426Z issue:#86 outcome:failure-lesson ts:2026-05-09T05:42:15.897Z -->
## Create the PR immediately after push — post-push verification burns turns needed for the deliverable

**After `git push` succeeds, call `gh pr create` as the very next action — before any `git log`, `git show --stat`, or `gh pr list` checks.**

**Why:** Post-push verification steps (confirming commit hashes, listing PRs, inspecting file stats) consume turns without advancing toward the actual deliverable. When a turn ceiling is close, these confirmation calls prevent PR creation from completing — leaving a fully-committed, fully-pushed branch with no open PR, which recovery passes can't fix in 4 turns if they also burn turns on re-verification.

**How to apply:** Write the PR body to a temp file early in the session (right after tests pass). After push, immediately call `gh pr create --body-file`. Reserve `git log` / `gh pr list` / `git show` only as diagnostics *if* the create step itself fails or returns an error.

**Tells:** Seeing `git log --oneline`, `git show --stat`, and `gh pr list` all appearing *after* `git push` but *before* `gh pr create` is the signature of turn-exhaustion-before-delivery risk.

<!-- run:run-2026-05-01T17-27-23-838Z issue:#604 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## When a config key ships in one surface, audit every other surface that enumerates the same keys

**When a new API key or config field is added to the schema, verify it appears in ALL surfaces that enumerate keys** — setup wizard, diagnostics/status tools, `noKeys`-style predicates, and docs. Any surface can lag independently.

**Why:** A key can ship in the wizard and on-disk schema while the diagnostics status tool silently omits it, leaving inconsistent 'set/unset' reporting for users. Issues filed against the wizard are often already fixed; the real remaining gap is a parallel reporting surface nobody updated.

**How to apply:** On any issue mentioning a missing field, grep for sibling field names (e.g., `etherscan`, `oneInch`) to locate every enumeration site. Update all of them atomically in the same PR.

**Tells:** Labels like `tool-gap` + `config-schema` + `diagnostics` together; a feature that appears to have shipped (commit cited in history) but the issue is still open; a diagnostics/status tool whose `apiKeys` interface is shorter than the wizard's field list.

Also: when an issue is partly stale (primary surface already fixed), do not close — re-scope to the remaining gap rather than abandoning the issue.

<!-- run:run-2026-05-02T06-32-08-433Z issue:#32 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Reuse existing sentinel formats when adding parallel output paths — extend with a new variant value

**When a plan calls for a separate sentinel or marker format for a new parallel path, prefer adding a variant value to the existing format instead.**
**Why:** A new sentinel shape forces every downstream consumer — pruner, filter, parser — to be updated simultaneously; missed updates cause silent data loss or double-processing. Extending the existing format (e.g. `outcome:failure-lesson` alongside `outcome:lesson`) leaves all current consumers compatible with zero changes and shrinks the diff surface.
**How to apply:** Before introducing a new sentinel shape, check whether the existing marker has a string/enum field that can carry a new value. Accept a wholly new format only when the semantics are genuinely incompatible with the existing shape.
**Tells:** Plan says 'introduce a separate sentinel format'; existing sentinel has a fixed `outcome:` or `type:` discriminator field; at least one downstream pruner/filter already handles the existing format.
**Corollary:** Apply the same principle to error classifiers — add an `isInfraFlake` (or equivalent noise-gate) guard on any new error-handling path so that transport / 5xx / filesystem failures that carry no learning value are silently dropped rather than producing junk output.
