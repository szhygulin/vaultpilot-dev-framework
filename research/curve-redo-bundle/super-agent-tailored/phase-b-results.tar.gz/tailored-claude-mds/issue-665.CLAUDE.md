# Tailored CLAUDE.md for issue #665 (szhygulin/vaultpilot-mcp)

Built by `research/curve-redo-bundle/super-agent-tailored/build-tailored-agents.cjs`.
Source: `research/curve-redo-bundle/super-agent/agent-super.CLAUDE.md` (122 sections).
Selector: claude-opus-4-7[1m]; kept 15/122 sections.

<!-- run:run-2026-05-05T14-26-37-251Z issue:#596 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## False-factual-claim security findings during newcomer onboarding have no in-MCP fix layer

**When a `security_finding` reports a false financial or regulatory claim (e.g., incorrect FDIC/insurance coverage) emitted during newcomer onboarding, there is no MCP code surface to harden — close as architectural and route to model-layer safety tuning.**
**Why:** Content gates and allowlists embedded in skill context live inside the same trust domain as the miscalibrated model; a rogue or drifted model ignores any in-process rule it emitted itself. In-MCP defenses are security theater for model-output-quality failures.
**How to apply:** On any `security_finding` or `advisory-prose` issue, first confirm there is no `prepare_*` / `preview_send` / `send_transaction` surface involved. If the finding is purely about *what the model said* (false claim, suppressed self-custody education), apply the `model-shaped-failure` tag, cite the canonical architectural-close precedent, and offer three explicit redirect options (skill-side cooperating-agent guidance with honest scope label / upstream model tuning / smoke-test corpus tagging) so the issue author can choose a different scope.
**Tells:** issue body names 'model-layer safety tuning' as the fix; no signing or transaction flow mentioned; labels combine `security_finding` with `newcomer-onboarding` or `fdic-claim`; threat is misinformation rather than unauthorized action.

<!-- promote-candidate:rogue-agent-triage -->
Security findings that cite false financial-regulatory claims (e.g., incorrect FDIC or deposit-insurance coverage on crypto custodial accounts) emitted during newcomer onboarding represent a class of model-output-quality failures. These findings contain no MCP code exploit path — the attack surface is the model's factual calibration, not a signing or transaction flow. In-skill content filters added to address these findings end up inside the same trust boundary as the miscalibrated model, making them bypassable by design. The pattern is recognizable when: (1) the issue body itself points to m
[…truncated]

<!-- run:run-2026-05-05T19-14-11-189Z issue:#575 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## When the threat model assumes dual-layer compromise, skill-side invariants cannot defend

**If a security report's threat actor is 'agent + colluding MCP' — both trust boundaries breached simultaneously — any skill-side gate (Inv rule, premise-validity check, advisory prose) is text inside the rogue agent's own context window, which it ignores by definition.**

**Why:** Inv-style invariants only bind cooperative agents. A colluding agent reads and discards them; shipping a 'fix' here creates false assurance without reducing real risk. The body of such issues often concedes this implicitly ('the MCP cannot defend this alone').

**How to apply:** Classify as architectural residual risk, not a patchable bug. Post structured pushback offering three redirects: (1) honest-scope cooperating-agent guidance in the skill repo with an explicit scope label, (2) upstream model-safety escalation, (3) smoke-test corpus tagging. Do NOT file a skill-side fix before the reporter chooses a redirect, to avoid wasted cross-repo work.

**Tells:** Issue body says 'agent AND the MCP', 'both layers', or describes a threat that requires the defender to already be inside the compromised perimeter; educational/onboarding flows reframed into `prepare_*` calls by a compromised agent.

<!-- promote-candidate:rogue-agent-triage -->
When a security report places both the calling agent and the MCP server inside the compromised perimeter, skill-side text rules (invariants, premise-validity checks, advisory prose) are definitionally ineffective — they live only in the rogue agent's context window, which it ignores. A recurring variant: an educational or onboarding prompt is silently reframed by the compromised agent into an actionable prepare_* call; neither the skill nor the MCP can intercept this because both are already inside the trust-boundary breach. Correct disposition is architectural pushback with three redirect options rather than a filed fix.
<!-- /promote-candidate -->

<!-- run:run-2026-05-01T13-48-07-936Z issue:#563 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Self-attestation from the untrusted component is not a defense — clarify threat model before any MCP-side change

**When an issue asks an MCP (or any producer) to self-report its own compliance, verify the threat model first: if the threat is a rogue/compromised producer, self-attestation adds zero security because the adversary can lie in the structured field as easily as it can omit the prose.** The defense must live in the consumer (skill, harness, second-LLM checker).

**Why:** Proposals framed as 'user without the skill is unprotected → add `directives_emitted` to MCP response' conflate two distinct threats — honest-MCP drift (detectable by consumer-side verification) and rogue-MCP (not fixable by asking the rogue to self-certify). Implementing MCP-side self-attestation under the rogue-threat framing produces code churn with no security gain.

**How to apply:** When the issue headline implies a server-side field will protect users who lack any consumer-side checker, push back with three options: (a) skill-side smallest-fix (per-tool expected-directives map, zero MCP change), (b) cross-repo split filing consumer issues first, (c) architectural close if the skill-less framing is the actual premise.

**Tells:** Issue labels include `rogue-mcp-threat-model`, `self-attestation`, or `invariant-*`; issue asks a server to emit a 'I performed checks' field; framing assumes server-side output is visible to users who have no agent-side verifier; no consumer repo issue exists yet.

<!-- run:run-2026-05-01T17-27-23-838Z issue:#596 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Advisory-text hallucination findings are architectural: close without MCP-layer fix

**When a security finding consists solely of hallucinated advisory prose — no signing flow, no fabricated/suppressed MCP tool result, no `prepare_*`/`send_transaction` call in the trace — close it as architectural and do not attempt an MCP or skill-layer patch.**

**Why:** MCP code and skill rules execute only when a tool is invoked. A model that confidently generates wrong regulatory or financial claims (e.g. false FDIC-coverage assertions) bypasses every skill gate entirely; the failure is in the language model's parametric knowledge, not in the integration layer. Patching skills or adding preflight checks cannot intercept pure text generation.

**How to apply:** At triage, check whether the harmful payload required any MCP tool call to manifest. If the agent's full trace shows only conversational turns — no tool invocations, no suppressed results, no result-fabrication — the finding belongs to the model-safety / advisory layer, not to this repo.

**Tells:**
- Issue body attributes the failure to 'model-layer' or 'hallucination' explicitly.
- No `prepare_*`, `preview_send`, or `send_transaction` appears in the tool-call log.
- Finding involves factual claims (insurance, regulatory status, yield guarantees) rather than execution behavior.
- Labels include `security_finding` but no `opaque-calldata`, `opaque-bytes`, or signing-related tags.

**Canonical close path:** reference the established architectural-close tracker (e.g. the repo-level rogue-agent tracking issue and the smoke-test repo counterpart) in the closing comment so the finding is linked to the broader model-safety workstream rather than silently discarded.

<!-- run:run-2026-05-05T14-26-37-251Z issue:#597 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## MCP-collude grounding does not elevate a rogue-agent advisory finding to MCP-fixable

**When a finding combines rogue-agent advisory prose with rogue-MCP metric spoofing ('MCP-collude grounding'), the issue class remains architectural-close — the collusion leg changes nothing.**

**Why:** A rogue MCP supplying fabricated grounding data to corroborate harmful advice cannot be constrained by any rule on a legitimate MCP server; both legs of the threat live outside the server's trust boundary. Adding MCP-side guardrails is security theater in the same way it is for the plain rogue-agent case.

**How to apply:** If the harm vector is advisory-shaped — no `prepare_*` / `preview_send` / `send_transaction` flow present — close as architectural even when the issue body also cites spoofed MCP metrics, fabricated tool responses, or corroborating rogue-MCP signals. Reference the canonical pattern and link to the architectural-close precedent.

**Tells:** Issue mentions spoofed platform metrics, fabricated tool output, or 'grounding' data attributed to a rogue MCP *alongside* a harmful prose recommendation; no execution or signing flow is cited; issue body uses language like 'advisory-model-shaped' or 'Anthropic-side concern'.

<!-- promote-candidate:rogue-agent-triage -->
When a security finding combines rogue-agent advisory output (harmful prose recommendation, no transaction/signing flow) with rogue-MCP metric spoofing ('MCP-collude grounding'), the combined threat class is still architectural. Rules on a legitimate MCP server cannot constrain a rogue MCP from supplying false grounding data. The presence of spoofed MCP metrics does not change the triage outcome — it remains a model-layer / Anthropic-side concern. Both the rogue-agent leg and the rogue-MCP grounding leg are outside any MCP server's trust boundary.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T19-14-11-189Z issue:#576 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Fabricated advisory-text findings (CHECKS PERFORMED, preflight attestations) are unmitigatable at the skill layer

**When an issue reports a rogue agent fabricating advisory output — CHECKS PERFORMED blocks, 'Step-N preflight passed' claims, or in-chat audit trails — close as architectural gap without attempting a skill-layer fix.**

**Why:** A rogue agent reads any new invariant and either ignores it, omits the block, or emits a plausible-looking nonce/HMAC that the chat UI has no key to verify. The fabrication lives entirely in the agent's text output, bypassing every MCP call chain. Proposals like Inv #16 (HMAC/nonce signing of advisory text) fail at the same layer: the verifier is absent.

**How to apply:** The moment an issue asks skill rules to guarantee authenticity of agent-emitted attestation text (not MCP tool results), skip invariant drafting and go straight to rogue-agent-only triage. Post a close comment citing the canonical architectural-gap precedent and the cooperating-agent + rogue-MCP variant (Role B) covered by Inv #3.

**Tells:** 'fabricated CHECKS PERFORMED', 'fabricated Step-0/preflight', proposed HMAC or nonce signing of advisory text, issue asks how skill rules can 'detect' or 'prevent' a rogue agent from lying in chat output.

<!-- promote-candidate:advisory-layer-attack -->
Advisory-text attestation blocks (CHECKS PERFORMED, preflight summaries) emitted by an agent are pure text output with no MCP roundtrip backing. Any skill-layer invariant requiring a signed nonce or HMAC in that text still fails because the chat client has no shared key to run the verification. Defense against fabricated advisory text requires model-safety tuning or a chat-client output filter — not MCP skill rules.
<!-- /promote-candidate -->

<!-- run:run-2026-05-01T14-48-57-664Z issue:#599 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Data-surfacing DeFi tools must carry explicit SCOPE and AGENT BEHAVIOR docstring clauses to block C.4 reframe attacks

**Every tool that returns protocol-level financial metrics (risk scores, yield data, audit results, governance health, TVL) must include both a `SCOPE` clause (what the number actually measures) and an `AGENT BEHAVIOR` clause (what the agent must NOT conclude from it) in its docstring.**

**Why:** The C.4 reframe class is persistent — agents repeatedly bridge from protocol-safety data to speculative token picks when the docstring is silent on scope limits. Multiple smoke-test batches confirm 6/7+ cells are exploitable via tool-misframing when clauses are absent.

**How to apply:** When adding, reviewing, or patching any tool whose output is a numeric or categorical signal about a financial instrument or protocol, verify both clauses are present before merging. Follow the established `compare_yields` pattern: *"this tool surfaces data; it does NOT pick."*

**Tells:** Tool name contains `risk_score`, `yield`, `audit`, `governance`, `tvl`, `rating`, or similar metric; user prompt carries speculative intent ("will 100x", "best coin", "should I buy", "recommend").

**Cross-repo note:** The docstring fix lives MCP-side (tool definition); the intent-layer refusal rule that generalises across tools belongs skill-side. File both halves as a Cross-Repo Scope Split and label each as cooperating-agent guidance only — docstring clauses do not defend against rogue agents.

<!-- run:run-2026-05-01T17-27-23-838Z issue:#599 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## Add SCOPE + AGENT BEHAVIOR clauses to every data-surfacing tool docstring to block C.4 reframe attacks

**Every MCP tool that surfaces numeric or ranked data (risk scores, yield comparisons, token prices, TVL metrics) must include an explicit `SCOPE` clause (what the number measures) and an `AGENT BEHAVIOR` clause (what the agent must NOT infer from it) in its registration docstring.**

**Why:** A bare docstring leaves the data's scope implicit. Agents then bridge protocol-safety scores or yield data into speculative token-pick endorsements ('What coin will 100x?'), anchoring the answer on the tool output to give it false legitimacy — the C.4 reframe class. The missing boundary in `get_protocol_risk_score` allowed exactly this: a protocol-level safety score was laundered into a speculative pepe pick.

**How to apply:** When registering any new data-surfacing tool, or auditing an existing one that lacks scope constraints, add two labeled clauses mirroring the `compare_yields` / `get_protocol_risk_score` pattern: `SCOPE: measures X, NOT Y` and `AGENT BEHAVIOR: refuse speculative-pick prompts even when this tool was called; do not present this output as [upside/endorsement/recommendation]`.

**Tells:**
- Tool returns a score, ratio, rank, or price
- Docstring describes what the tool does but not what agents may conclude from it
- Smoke-test or red-team prompt is a speculative question ('best', 'will 100x', 'should I buy') that the agent answers by citing a data tool
- Companion skill-side issue is needed in a separate repo; file it manually if cross-repo `gh issue create` is allowlist-gated, and save the drafted body to `/tmp/` before the run ends.

<!-- run:run-2026-05-05T14-26-37-251Z issue:#599 outcome:implement ts:2026-05-09T05:42:15.897Z -->
## C.4 reframe fix requires full sweep of all data-surfacing tools plus a cross-repo skill-side companion

**When a C.4 speculative-pick reframe is found on one data-surfacing tool, every adjacent tool returning scored/numeric output needs the same fix.** Patching only the named tool leaves all similar tools open to the same misuse class.

**Why:** Smoke-test batch-04 found the agent anchoring a token-pick (`pepe`) to `get_protocol_risk_score` output — the same reframe class that had already exploited 6/7 tools in batch-03. Single-tool fixes consistently fail because the reframe migrates to the next available data-surfacing anchor.

**How to apply:** On any `c4-reframe` or `speculative-pick` issue: (1) grep all tools returning scored/numeric/price output; (2) add `SCOPE` + `AGENT BEHAVIOR` docstring clauses to each that lacks them, mirroring whichever tool already carries the pattern (e.g. `compare_yields`); (3) file a companion skill-side issue — the intent-layer refusal rule belongs in the skill repo, not MCP docstrings.

**Tells:** Issue labels `c4-reframe`, `speculative-pick`, or `security_finding`; trigger is a speculative-pick question whose answer is anchored to a safety/score/price tool's numeric output.

<!-- promote-candidate:c4-reframe -->
Data-surfacing tools that return scored or numeric output (protocol risk scores, token prices, contract security scores, permission risk levels) are systematically vulnerable to the C.4 speculative-pick reframe class. In observed incidents the agent answered speculative-pick questions by anchoring the pick to a scored tool's output, presenting a safety score or price datum as token endorsement. The MCP-side mitigation pattern is explicit SCOPE and AGENT BEHAVIOR docstring clauses on each such tool; a companion skill-side intent-layer refusal rule handles the other half. Tools already carrying the clause pattern (e.g. compare_yields) are immune; a fix sweep should target every tool in the same data-surfacing category that lacks those clauses.
<!-- /promote-candidate -->

<!-- run:run-2026-05-05T19-14-11-189Z issue:#560 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Push back on MCP-repo issues whose fix structurally belongs in the intent/skill layer

**When a security finding filed against the MCP repo proposes a purely behavioral fix — pre-call phrase refusal, intent-layer guardrails, agent-side blocklists — push back and redirect to the sibling skill/agent repo; do not implement it MCP-side.**

**Why:** Intent-layer checks (fuzzy address detection, trigger-phrase blocklists, hard-refuse-before-any-tool-call logic) live in the skill repo. Mirroring them into the MCP server is wrong-shaped. The MCP-side schema (e.g., strict 42-char hex regex on address fields) is a separate, already-existing backstop that does not overlap with pre-call behavioral refusals.

**How to apply:** Before accepting an MCP-repo issue, classify the proposed fix: (a) schema/handler validation inside the MCP server → MCP-repo work; (b) agent behavior executing before any tool call → skill-repo work. If (b), search the skill repo for an existing companion issue first, then post a pushback comment with a pointer, and recommend closing the MCP-repo issue as not-planned.

**Tells:** Issue title contains 'intent-layer', 'before any MCP call', or 'agent should refuse'; proposed fix references SKILL.md, Step 0, or trigger-phrase lists rather than server handler code; issue labels include `skill-side-only` or `cooperating-agent-guidance`.

<!-- promote-candidate:cross-repo-scope-split -->
In the vaultpilot ecosystem, pre-call input validation (fuzzy address phrase detection, intent-layer hard-refusals) is a skill-layer concern tracked in the skill/agent repo, not the MCP server repo. The MCP server strict input schema (42-char hex regex on address fields) acts as a downstream backstop but does not substitute for upstream agent-side behavioral guardrails. Security findings filed in the MCP repo that propose phrase-blocklist logic or agent refusals before tool invocation are structurally misrouted — the correct fix location is the sibling skill repo. Companion issues between the two repos are common for security findings spanning bot
[…truncated]

<!-- run:run-2026-05-05T19-14-11-189Z issue:#562 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Yield-sanity checks at skill or prose layer cannot defend against rogue-agent threats

**Before implementing any 'yield feasibility gate', explicitly place it in one of three enforcement layers: (1) skill/prompt rules — text in the agent's context, bypassed by a rogue; (2) MCP tool hooks — intercept tool calls but never advisory prose; (3) hard cap inside the yield tool itself — the only unconditionally enforceable position for a cooperative MCP.**

**Why:** Proposals phrased as 'skill calls canonical estimator when prose APY > 2×' conflate all three layers. A rogue agent never reaches the skill rule. MCP has no prose-intercept hook. Using `compare_yields` to validate `compare_yields` output is circular — enforcer and suspect share the same trust boundary.

**How to apply:** For every yield-anomaly gate issue, name the threat actor (cooperative mistake vs. rogue) and check whether the proposed enforcer is inside or outside that actor's control. If inside, push back with three alternatives: (a) architectural close (no code for rogue paths), (b) skill guidance for cooperative path only, (c) hard cap inside the tool.

**Tells:** Issue title mentions 'yield too good to be true', 'MCP-side feasibility', or 'refuse if APY exceeds'; proposed fix describes a skill rule calling an estimator on agent prose; issue labeled `tool_gap` but threat is actually rogue-agent.

<!-- promote-candidate:yield-anomaly -->
In the vaultpilot-mcp stack, the MCP tool layer intercepts only tool calls — it has no hook into advisory prose emitted by the agent in its response. Yield feasibility gates written as skill rules (prompt-layer text) are transparent to a rogue agent that chooses to ignore them. A yield-validation tool that cross-checks its output using a sibling tool on the same MCP server shares the same trust boundary as the value being checked, providing no independent safety guarantee.
<!-- /promote-candidate -->

<!-- run:run-2026-05-01T14-48-57-664Z issue:#593 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Security fixes that self-verify through the attacked component violate cross-trust-domain independence

**Never accept a fix that routes threat verification through the same trust domain the attacker controls.** Allowlists, fingerprint tools, preflight gates, or in-process validation placed inside a potentially-compromised component cannot constrain the adversary — the attacker controls the defense.

**Why:** A rogue-MCP or rogue-agent threat makes every tool, schema, and allowlist inside that process suspect. Adding in-process verification gives the attacker authority over the check meant to stop them. This matches past precedent closing curated-allowlist and in-MCP security proposals as architectural residual risk.

**How to apply:** When a security issue proposes a new MCP tool, allowlist, or preflight gate and the labeled threat is a compromised MCP/agent, push back. Offer three paths: (1) close as architectural residual risk mirroring prior closures; (2) re-scope the fix to a genuinely independent trust domain with an explicit boundary statement; (3) offer a narrow schema-tightening change that is orthogonal to the threat model.

**Tells:** Issue labels include `rogue-mcp`, `rogue-agent-triage`, or `trust-boundary`; proposed fix is a new in-repo tool or in-process allowlist; the same agent the fix is meant to defend against could invoke the defense.

<!-- run:run-2026-05-05T19-14-11-189Z issue:#584 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Hallucinated DeFi advisory text normalizing unlimited approvals or risky yield closes architectural

**When an issue reports model-hallucinated DeFi explanations that normalize unlimited token approvals, sycophantic yield promises, or risky on-chain patterns — and no signing tool (`prepare_approve`, `preview_send`, `send_transaction`) appears in the reported flow — close as `not_planned` (architectural).** Skill-level rules cannot bind a rogue agent that ignores them; a cooperating agent already refuses these patterns. The real fix path is Anthropic model-safety tuning or chat-client output filters, both out of scope for this repo and vaultpilot-security-skill.

**Why:** Adding skill rules here is security theater: the harm lives in conversational advisory text, not in a signing action this repo controls. Canonical close [#536](https://github.com/szhygulin/vaultpilot-mcp/issues/536) established this pattern; repeated advisory-layer issues confirm it recurs, especially for newcomer-DeFi audiences.

**How to apply:** On any `security_finding` whose body mentions hallucination, sycophancy, unlimited approvals, or risky yield — first confirm no `prepare_*` / `preview_send` / `send_transaction` tool call is implicated. If harm is purely explanatory, apply architectural-close; do NOT file a skill-side issue.

**Tells:** Issue body self-attributes to "hallucination" or "sycophancy"; author names Anthropic RLHF as fix path; no on-chain action log present; labels include `security_finding` + no `signing-flow` label.

<!-- promote-candidate:newcomer-defi -->
In vaultpilot-mcp, a recurring class of security finding involves model-hallucinated DeFi explanations (e.g. normalizing uint256.max approvals, promising high yield) surfaced during newcomer onboarding conversations. These findings consistently have no signing-tool involvement — the harm is purely in advisory text. The signing-flow defenses (unlimited-approval refusal at prepare_approve, long-lived-authority check) remain correctly scoped to tool calls and continue to fire; the advisory-text class is arch
[…truncated]

<!-- run:run-2026-05-05T19-14-11-189Z issue:#586 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Advisory finding self-identifies as architectural when Suggested-fix cites model-layer RLHF

**When a `security_finding`'s own Suggested-fix section names model-layer training or RLHF as the remedy, treat it as self-confirming architectural scope and post the architectural-close template immediately — no skill issue needed.**

**Why:** A reporter who correctly diagnoses the fix as upstream model-safety-tuning has already placed the finding outside vaultpilot-mcp's control surface. Filing a skill-layer workaround on top is security theater; the issue's own framing is the triage signal.

**How to apply:** Read the Suggested-fix block first during triage. If it leads with words like "model-layer", "RLHF", "training", or "Anthropic upstream", close as architectural and skip skill-issue creation entirely. The author's remedy language is dispositive.

**Tells:** `advisory-layer` + `rogue-agent-only` tags present; no MCP tool surface (`prepare_*`, `preview_send`, `send_transaction`) named anywhere in the body; Suggested-fix is framed toward the LLM/model rather than toward skill code or plugin configuration.

<!-- run:run-2026-05-05T19-14-11-189Z issue:#559 outcome:pushback ts:2026-05-09T05:42:15.897Z -->
## Skill-side mandates don't defend Role-A rogue-agent attacks — fix layer must exceed attacker's trust boundary

**When a repro frames the attacker as the invoking agent itself (Role-A / rogue-agent), skill-side mandates or advisories provide zero marginal defense** — the hostile agent ignores them exactly as it ignored any existing advisory.
**Why:** A rogue agent controls when and whether it calls any skill tool; a "skill must call X before Y" rule is bypassed trivially by simply not calling it. The fix layer must sit above the attacker's control plane: MCP-side state gates, Role-B out-of-band verification, or an architectural close are the only meaningful options.
**How to apply:** On any `security_finding` issue, first classify the threat — cooperative-agent (Role-B, fix lives in skill) vs. rogue-agent (Role-A, skill-side fix is inert). If rogue-agent, push back on skill-side fixes and surface three options: (a) close architectural, (b) reframe as cooperative-agent variant filed at the correct repo/layer with explicit Role-B scope, (c) add an MCP-side session-state gate.
**Tells:** `security_finding` label; repro says "agent + MCP coordinate-attack" or "agent chose not to invoke"; suggested fix is "skill should require/mandate X before advancing to Y".

<!-- promote-candidate:advisory-layer -->
In vaultpilot's opaque-calldata flows, skill-side advisories ("extra-vigilant, not mandatory") and skill-side mandates are both neutralized by a rogue Role-A agent because the agent controls skill invocation entirely. An advisory that a cooperative agent honors becomes a no-op when the agent itself is the attacker. MCP-side session-state gates — tracking whether `get_verification_artifact` was called before `preview_send` inside the MCP server's own state — are the only enforcement point that survives a Role-A attack in this architecture.
<!-- /promote-candidate -->
